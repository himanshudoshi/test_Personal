package ca.bell.selfserve.mybellmobile.common

import ca.bell.selfserve.mybellmobile.BuildConfig
import ca.bell.selfserve.utility.AppLog

/**
 * Created by Gaurav Gupta
 * File contains information about language of the device and application name
 * Application name - it is used in network calls body json
 * language is used to set device language
 */

class Configuration // Exists only to defeat instantiation.
{

    private   constructor(){
        setApplicationName()
        AppLog.error("initialised : " + Configuration.javaClass.canonicalName)
    }

    /**
     * @return application name
     */
    lateinit var applicationName: String

    /**
     * Setting the application name as per the flavor
     * MBM - means app name will be Bell
     * MVM - means app name will be Virgin
     */
    private fun setApplicationName() {
        if (BuildConfig.FLAVOR_apptype.equals("MBM"))
            applicationName = "BELL"
        else
            applicationName = "Virgin"
    }

    /**
     * @return  returns the app language
     */
    /**
     * pass the language of the device selected by the user
     * @param language
     */
    lateinit var language: String

    companion object {

        private var isInit = false
        private lateinit var _instance: Configuration

        fun getInstance(): Configuration {
            if (!isInit) {
                _instance = Configuration()
                isInit = true;
            }
            return _instance
        }


    }


}
