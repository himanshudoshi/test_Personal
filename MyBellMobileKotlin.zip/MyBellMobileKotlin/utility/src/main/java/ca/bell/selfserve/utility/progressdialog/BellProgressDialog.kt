package ca.bell.selfserve.mybellmobile.dialog.progressdialog

import android.app.ProgressDialog
import android.content.Context
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import ca.bell.selfserve.utility.R


/**
 * Created by Gaurav Gupta on 1/13/2018.
 */

class BellProgressDialog(context: Context) : ProgressDialog(context) {


    override fun onCreate(savedInstanceState: Bundle) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.custom_loader)
        window!!.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
        setTitle(null)
        setMessage(null)
    }

    fun showDialog() {
        mInstance.show()
    }

    fun hideDialog() {
        mInstance.dismiss()
    }

    companion object {
        lateinit var mInstance: BellProgressDialog

        fun getInstance(context: Context): BellProgressDialog {
            mInstance = BellProgressDialog(context)
            mInstance.isIndeterminate = true
            mInstance.setCancelable(false)
            mInstance.setCanceledOnTouchOutside(false)
            return mInstance
        }
    }
}
