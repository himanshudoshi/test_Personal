package ca.bell.selfserve.mybellmobile.common

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v4.content.PermissionChecker
import ca.bell.selfserve.mybellmobile.R
import java.util.ArrayList
import java.util.HashMap
import java.util.Map


/**
 * Created by Gaurav Gupta on 9/25/17.
 * Common utility to show permissions in the application
 */
object PermissionUtils {


    private val TAG = "MarshMallowUtils"

    interface PermissionNames {
        companion object {
            val FINE_LOCATION = "ACCESS_FINE_LOCATION"
            val COARSE_LOCATION = "ACCESS_COARSE_LOCATION"
            val WRITE_EXTERNAL = "WRITE_EXTERNAL_STORAGE"
        }
    }

    interface PermissionValues {
        companion object {
            val FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION
            val COARSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION
            val WRITE_EXTERNAL=Manifest.permission.WRITE_EXTERNAL_STORAGE
        }
    }


    /**
     * @param context
     * @param permission
     * @return this function checks whether a permission is granted or not to the app.
     */
    fun isPermissionGranted(context: Context, permission: String): Boolean {
        val permissionValue = ContextCompat.checkSelfPermission(context, permission)
        return (permissionValue == PermissionChecker.PERMISSION_GRANTED)
    }

    /**
     * @param activity    activity which require the permission
     * @param permission  permission string to be granted
     * @param requestCode an integer numper assigned to this request for permission
     * @param message     any message to be shown to user.(error.g. why this permission in required)
     *
     *
     * To check the result of this method call, implement a callback method in your activity
     * info.error.  public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults)
     *
     *
     * Even if you need the permission in fragment, the callback method of activity will be called.
     */
    fun requestPermission(activity: Activity, permission: String, requestCode: Int, message: String) {

        ActivityCompat.requestPermissions(activity, arrayOf(permission), requestCode)
    }

    /**
     * @param activity
     * @param permissions string array of permissions to be granted.
     * @param requestCode an integer numper assigned to this request for permission
     * @param message     message to be shown to user regarding permission access.
     */
    fun requestPermission(activity: Activity, permissions: Array<String>, requestCode: Int, message: String) {
        ActivityCompat.requestPermissions(activity, permissions, requestCode)
    }

    /**
     * @param activity
     * @param permissions hasmap of permission need to be checked for access.
     * @param requestCode an integer numper assigned to this request for permission
     *
     *
     * This method prepare the message to be shown to the user from passed keys in hashmap(permissions) and request for required permimssion.
     */
    fun requestPermission(activity: Activity, permissions: HashMap<String, String>, requestCode: Int) {

        var message = activity.resources.getString(R.string.message_need_multiple_permission)
        var needPermission = false//check whether to show some message or not.
        for ((key, value) in permissions) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, value )) {
                needPermission = true
                message += key + ","
            }
        }
        if (!needPermission) {
            message = ""
        } else if (message.endsWith(",")) {
            message = message.substring(0, message.length - 1)
        }
        val per = ArrayList(permissions.values)
        requestPermission(activity, per.toTypedArray(), requestCode, message)
    }

    /**
     * @param context
     * @param permissions hasmap of permission need to be checked for access.
     * @return returns a filtered hashmap from input hashmap with permissions to be granted
     *
     *
     * This method is to check multiple permissions at once for access.
     */
    fun checkForMultiplePermissionsToGrant(context: Context, permissions: HashMap<String, String>): HashMap<String, String> {
        val iterator = permissions.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next() as Map.Entry<*, *>
            if (isPermissionGranted(context, entry.value.toString())) {
                iterator.remove()
            }
        }
        return permissions
    }

    /**
     * contains code to show a dialog
     * @param context
     * @param message
     * @param okListener
     */
    fun showDialog(context: Context, message: String, okListener: DialogInterface.OnClickListener) {

    }

}
