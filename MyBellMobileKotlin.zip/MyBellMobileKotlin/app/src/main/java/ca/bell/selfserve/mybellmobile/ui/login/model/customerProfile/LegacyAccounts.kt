package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
/**
 * Created by Gaurav Gupta on 5/1/2018.
 */
data class LegacyAccounts (

    var mobilityAccounts: MobilityAccounts? = null,
    var tvaccounts: Tvaccounts? = null,
    var iptvaccounts: Iptvaccounts? = null,
    var wirelineAccounts: WirelineAccounts? = null,
    var internetAccounts: InternetAccounts? = null

)