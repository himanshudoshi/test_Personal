package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class SubscriberItem(

        @field:SerializedName("lastUpdateStamp")
        val lastUpdateStamp: Int? = null,

        @field:SerializedName("accountCommPref")
        val accountCommPref: Any? = null,

        @field:SerializedName("contractType")
        val contractType: ContractType? = null,

        @field:SerializedName("lastUpdateDate")
        val lastUpdateDate: Long? = null,

        @field:SerializedName("subscriberStatus")
        val subscriberStatus: String? = null,

        @field:SerializedName("subscriberID")
        val subscriberID: String? = null,

        @field:SerializedName("language")
        val language: Language? = null,

        @field:SerializedName("paccPinStatus")
        val paccPinStatus: PaccPinStatus? = null,

        @field:SerializedName("telcoId")
        val telcoId: String? = null,

        @field:SerializedName("commitmentTerm")
        val commitmentTerm: Int? = null,

        @field:SerializedName("hasRoamingDataServices")
        val hasRoamingDataServices: Boolean? = null,

        @field:SerializedName("emailAddress")
        val emailAddress: String? = null,

        @field:SerializedName("initialPassword")
        val initialPassword: String? = null,

        @field:SerializedName("cancelledSubStatusDate")
        val cancelledSubStatusDate: Any? = null,

        @field:SerializedName("hasDomesticDataServices")
        val hasDomesticDataServices: Boolean? = null,

        @field:SerializedName("thunderBayIndicator")
        val thunderBayIndicator: String? = null,

        @field:SerializedName("hardware")
        val hardware: Hardware? = null,

        @field:SerializedName("isCallDisplayAllowed")
        val isCallDisplayAllowed: Boolean? = null,

        @field:SerializedName("wcoCDate")
        val wcoCDate: Long? = null,

        @field:SerializedName("hasOrderInProgress")
        val hasOrderInProgress: Boolean? = null,

        @field:SerializedName("subMarket")
        val subMarket: Submarket? = null,

        @field:SerializedName("initialActivationDate")
        val initialActivationDate: Long? = null,

        @field:SerializedName("lastHardwareUpgradeDate")
        val lastHardwareUpgradeDate: Any? = null,

        @field:SerializedName("isAccountSMSPerm")
        val isAccountSMSPerm: Boolean? = null,

        @field:SerializedName("isWCoCSubscriber")
        val isWCoCSubscriber: Boolean? = null,

        @field:SerializedName("deviceGroupNickName")
        val deviceGroupNickName: Any? = null,

        @field:SerializedName("telephoneNumber")
        val telephoneNumber: String? = null,

        @field:SerializedName("internetV2Number")
        val internetV2Number: Any? = null,

        @field:SerializedName("domesticDSBlockedUntil")
        val domesticDSBlockedUntil: Any? = null,

        @field:SerializedName("roamingDSBlockedUntil")
        val roamingDSBlockedUntil: Any? = null,

        @field:SerializedName("portabilityIndicator")
        val portabilityIndicator: String? = null,

        @field:SerializedName("portInidicator")
        val portInidicator: Any? = null,

        @field:SerializedName("nickname")
        val nickname: String? = null,

        @field:SerializedName("pinUnlockKey")
        val pinUnlockKey: List<Int?>? = null,

        @field:SerializedName("manitobaIndicator")
        val manitobaIndicator: String? = null,

        @field:SerializedName("pricePlan")
        val pricePlan: String? = null,

        @field:SerializedName("networkType")
        val networkType: NetworkType? = null,

        @field:SerializedName("subscriberEstablishDate")
        val subscriberEstablishDate: Long? = null,

        @field:SerializedName("productType")
        val productType: ProductType? = null,

        @field:SerializedName("commitmentEndDate")
        val commitmentEndDate: Long? = null,

        @field:SerializedName("isAccessible")
        val isAccessible: Boolean? = null,

        @field:SerializedName("serviceArea")
        val serviceArea: String? = null,

        @field:SerializedName("commitmentStartDate")
        val commitmentStartDate: Long? = null,

        @field:SerializedName("nextTopupDate")
        val nextTopupDate: Long? = null,

        @field:SerializedName("primeMateInidicator")
        val primeMateInidicator: PrimeMateInidicator? = null,

        @field:SerializedName("isBillSixty")
        val isBillSixty: Boolean? = null,

        @field:SerializedName("birthDate")
        val birthDate: Any? = null,

        @field:SerializedName("daysSinceActivation")
        val daysSinceActivation: Int? = null,

        @field:SerializedName("promotionGroupCode")
        val promotionGroupCode: Any? = null,

        @field:SerializedName("isTab")
        val isTab: Boolean? = null,

        @field:SerializedName("subscriberName")
        val subscriberName: String? = null,

        @field:SerializedName("padPinStatus")
        val padPinStatus: PadPinStatus? = null,

        @field:SerializedName("primeSubNumber")
        val primeSubNumber: Any? = null,

        @field:SerializedName("daysSinceLastHWUpgrade")
        val daysSinceLastHWUpgrade: Any? = null,

        @field:SerializedName("deferredAmount")
        val deferredAmount: DeferredAmount? = null,

        @field:SerializedName("deviceGroup")
        val deviceGroup: Any? = null
)