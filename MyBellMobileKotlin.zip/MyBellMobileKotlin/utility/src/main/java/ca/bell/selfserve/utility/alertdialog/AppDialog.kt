package ca.bell.selfserve.mybellmobile.alertdialog

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */

data class AppDialog (
        //jj

        var title: String?=null,
        var message: String?=null,
        var okBtnText: String?=null,
        var cancelBtnText: String?=null,
        var hideTitle: Boolean,
        var hideCancelButton: Boolean,
        var hideOkButton: Boolean,
        var hasSmallBtn: Boolean

){
    constructor() : this("", "",
            "", "", false,
            false, false, false

    )

    //Builder Class
    class AppDialogBuilder(private val title: String, private val message: String) {
        private var okBtnText: String? = null
        private var cancelBtnText: String? = null
        private var hideTitle: Boolean = false
        private var hideCancelButton: Boolean = false
        private var hideOkButton: Boolean = false
        private var hasSmallBtn: Boolean = false


        fun setokBtnText(okBtnText: String): AppDialogBuilder {
            this.okBtnText = okBtnText
            return this
        }

        fun setcancelBtnText(cancelBtnText: String): AppDialogBuilder {
            this.cancelBtnText = cancelBtnText
            return this
        }

        fun sethideTitle(hideTitle: Boolean): AppDialogBuilder {
            this.hideTitle = hideTitle
            return this
        }

        fun sethideCancelButton(hideCancelButton: Boolean): AppDialogBuilder {
            this.hideCancelButton = hideCancelButton
            return this
        }

        fun sethideOkButton(hideOkButton: Boolean): AppDialogBuilder {
            this.hideOkButton = hideOkButton
            return this
        }

        fun sethasSmallBtn(hasSmallBtn: Boolean): AppDialogBuilder {
            this.hasSmallBtn = hasSmallBtn
            return this
        }

        fun build(): AppDialog {
            return AppDialog(this)
        }

    }

    constructor(appDialogBuilder: AppDialog.AppDialogBuilder) : this()
}