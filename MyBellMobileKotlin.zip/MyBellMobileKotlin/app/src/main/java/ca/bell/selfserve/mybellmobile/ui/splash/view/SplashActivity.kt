package ca.bell.selfserve.mybellmobile.ui.splash.view

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.widget.ProgressBar
import ca.bell.selfserve.mybellmobile.R
import ca.bell.selfserve.mybellmobile.alertdialog.AppDialog
import ca.bell.selfserve.mybellmobile.alertdialog.BellErrorDialog
import ca.bell.selfserve.mybellmobile.alertdialog.IErrorDialogListner
import ca.bell.selfserve.mybellmobile.base.BaseActivity
import ca.bell.selfserve.utility.AppConstant
import ca.bell.selfserve.utility.AppLog
import ca.bell.selfserve.utility.AppLog.info
import ca.bell.selfserve.mybellmobile.common.Configuration
import ca.bell.selfserve.mybellmobile.common.PermissionUtils
import ca.bell.selfserve.mybellmobile.ui.login.view.LoginActivity
import ca.bell.selfserve.mybellmobile.ui.splash.SplashContract
import ca.bell.selfserve.mybellmobile.ui.splash.model.ForceUpgradeCMSContent
import ca.bell.selfserve.mybellmobile.ui.splash.presenter.SplashPresenter


/**
 * IBlackPanelView For SplashActivity Screen
 */
class SplashActivity : BaseActivity(), SplashContract.ISplashView, ActivityCompat.OnRequestPermissionsResultCallback {
    private var iSplashPresenter: SplashContract.ISplashPresenter? = null
    private var mContext: Context? = null
    private var mProgressBar: ProgressBar? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        // set up references
        mContext = this
        //attach splash presenter to splash view
        attachPresenter()

        setUpUi()
    }


    private fun setUpUi() {
        mProgressBar = findViewById(R.id.progressBar)
    }


    override fun attachPresenter() {
        if (lastCustomNonConfigurationInstance != null)
            iSplashPresenter = lastCustomNonConfigurationInstance as SplashContract.ISplashPresenter

        if (iSplashPresenter == null) {
            iSplashPresenter = SplashPresenter()
        }
        iSplashPresenter!!.attachView(this)
        iSplashPresenter!!.attachLoader(this.supportLoaderManager)
    }

    override fun onStart() {
        super.onStart()


        /**
         * call checkLocationPermissionAvailability method in splash presenter
         * if true call detect app language method
         * if false call requestLocationPermission method in utility class
         */
        // check for location permission
        if (iSplashPresenter!!.checkLocationPermissionAvailability(mContext!!)) {
            //            mUtility.requestLocationPermissions(this, 0);
            val requiredPermissionNames = PermissionUtils.checkForMultiplePermissionsToGrant(mContext!!, iSplashPresenter!!.requiredPermissionNames)
            if (requiredPermissionNames.size > 0)
                PermissionUtils.requestPermission(this, requiredPermissionNames, 0)
            else
                iSplashPresenter!!.proceedWithAppLanguage()
        } else
            iSplashPresenter!!.proceedWithAppLanguage()

    }

    override fun onResume() {
        super.onResume()

    }

    /**
     * callback for permission call
     *
     * @param requestCode  -request code
     * @param permissions  - array of permissions
     * @param grantResults - array of granted results
     */
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        info("onRequestPermissionsResult function called")
        if (requestCode == 0) {
            /*Callback after showing location permission.*/
            info("User has taken decision on location permission.")
            iSplashPresenter!!.proceedWithAppLanguage()
        }
    }


    override fun displayLanguageSelectionPopup(): Boolean {

        var appDialog = AppDialog()
        with(appDialog) {
            title = "Choose Language"
            message = resources.getString(R.string.language_selection)
            okBtnText = "English"
            cancelBtnText = "Français"
            hideOkButton = false
            hideCancelButton = false
            hideTitle = true
            hasSmallBtn = false

        }

        BellErrorDialog(this@SplashActivity, appDialog, object : IErrorDialogListner {
            override fun onOkButtonPressed(dialogue_custom: Dialog) {
                info("onOk Button pressed")
                info("User selected english language.")
                iSplashPresenter?.setAppLanguage(AppConstant.languageNames.ENGLISH)
            }

            override fun onCancelButtonPressed(dialogue_custom: Dialog) {
                info("onCancel Button pressed")
                info("User selected french language.")
                iSplashPresenter?.setAppLanguage(AppConstant.languageNames.FRENCH)

            }
        }).showDialog()

        return true
    }

    override fun showLoginScreen() {

        callLogin()
    }


    fun callLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()

    }

    override fun showLandingScreen() {
        /*  startActivity(new Intent(this, LandingActivity.class));
        finish();*/
    }

    override fun onRetainCustomNonConfigurationInstance(): Any? {
        return iSplashPresenter
    }

    override fun getConfigurationFromServer() {
        iSplashPresenter!!.callConfigurationApi()
    }

    override fun checkNetworkConnection() {
        iSplashPresenter!!.checkIfNetworkIsAvailable()
    }

    override fun showForceUpgradePopup(forceUpgradeCMSContent: List<ForceUpgradeCMSContent>) {
        var content: ForceUpgradeCMSContent? = null
        val appLanguage = Configuration.getInstance().language
        for (i in forceUpgradeCMSContent.indices) {
            val language = forceUpgradeCMSContent[i].language
            if (appLanguage == language) {
                content = forceUpgradeCMSContent[i]
            }
        }


        var appDialog = AppDialog()
        with(appDialog) {
            title = content!!.title
            message = content?.message
            okBtnText = content?.okBtn
            cancelBtnText = content?.cancelBtn
            hideOkButton = false
            hideCancelButton = false
            hideTitle = false
            hasSmallBtn = false

        }

        BellErrorDialog(this@SplashActivity, appDialog, object : IErrorDialogListner {
            override fun onOkButtonPressed(dialogue_custom: Dialog) {
                AppLog.debug("onOk Button pressed")

                iSplashPresenter!!.goToPlayStore()
            }

            override fun onCancelButtonPressed(dialogue_custom: Dialog) {
                AppLog.debug("onCancel Button pressed")

            }
        }).showDialog()


    }


    override fun showConnectionError(): Boolean {
        val resources = mContext!!.resources

        var appDialog = AppDialog()
        with(appDialog) {
            title = resources.getString(R.string.login_netError)
            message = resources.getString(R.string.login_connection_unavailable_message)
            okBtnText = null
            cancelBtnText = resources.getString(R.string.login_connection_unavailable_close)
            hideOkButton = true
            hideCancelButton = false
            hideTitle = false
            hasSmallBtn = true

        }

        BellErrorDialog(this@SplashActivity, appDialog, object : IErrorDialogListner {
            override fun onOkButtonPressed(dialogue_custom: Dialog) {
                AppLog.debug("User proceed with forceUpgrade")
            }

            override fun onCancelButtonPressed(dialogue_custom: Dialog) {
                AppLog.debug("showConnectionError ok pressed")
                System.exit(0)
            }
        }).showDialog()


        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        iSplashPresenter!!.detachView()
    }
}

