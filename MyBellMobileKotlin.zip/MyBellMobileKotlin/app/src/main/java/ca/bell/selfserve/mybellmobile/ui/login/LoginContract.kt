package ca.bell.selfserve.mybellmobile.ui.login

import android.content.Context
import ca.bell.selfserve.mybellmobile.base.BasePresenter
import ca.bell.selfserve.mybellmobile.base.BaseView

/**
 * Created by AU00538779 on 5/4/2018.
 */
class LoginContract {

    /**
     * interface that splash activity will implement
     */
    interface ILoginView : BaseView<ILoginPresenter> {

        val editTextPassword: String

        val keepMeState: Boolean

        val context: Context

        fun showProgress()

        fun hideProgress()

        fun setUsernameError()

        fun setPasswordError()

        fun navigateToHome()

        fun navigateToRecoveryFlow()

        fun navigateToRegisterFlow()

        fun showErrorDialog(key: Int)
    }

    /**
     * interface that splash presenter will implement
     */
    interface ILoginPresenter : BasePresenter {
        fun onRegisterClick()

        fun onRecoveryClick()

        fun startBUPAuthentication(userName: String, password: String)

        fun authenticateUser(userName: String, password: String)

    }
}