package ca.bell.selfserve.mybellmobile.exception



class CustomExceptionHandler(private val exceptionHandler: IExceptionHandler) : Thread.UncaughtExceptionHandler {

    private val rootHandler: Thread.UncaughtExceptionHandler

    init {
        // we should store the current exception handler -- to invoke it for all not handled exceptions ...
        rootHandler = Thread.getDefaultUncaughtExceptionHandler()
        // we replace the exception handler now with us -- we will properly dispatch the exceptions ...
        Thread.setDefaultUncaughtExceptionHandler(this)

    }

    override fun uncaughtException(thread: Thread, ex: Throwable) {

        // always system exit after handling uncaught exception
        if (ex is RuntimeException) {
            //
            exceptionHandler.onUncaughtException(thread, ex)
        } else {
            //default android exception handling
            rootHandler.uncaughtException(thread, ex)

        }
    }
}