package ca.bell.selfserve.mybellmobile.ui.splash.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
class AppFlag {

    @SerializedName("flagName")
    @Expose
    var flagName: String? = null
    @SerializedName("flagValue")
    @Expose
    var isFlagValue: Boolean = false


}
