package ca.bell.nmf.ui.localization

import android.content.Context
import android.content.res.Configuration
import android.os.Build

import java.util.Locale

/**
 * This class is used to manage the changes for Locale Lang of the app
 */
open class LanguageManager(context: Context) {

    /**
     * @property mContext the context object which requested the Locale Lang change.
     */
    private val mContext = context

    /**
     * @property userLocaleLanguage used to determine the current Locale Lang of the app.
     * if empty from SharedPreferences, it will return the Language from the device Locale configuration.
     */
    val userLocaleLanguage: String
        get() {
            val internalData = InternalData(mContext)
            val currentLanguage = internalData.getCurrentLanguage()
            return if (currentLanguage.isNotEmpty()) {
                currentLanguage
            } else {
                getContextLanguageLocale()
            }
        }

    /**
     * @property shouldShowLanguageLocaleDialog is a flag from SharedPref that keeps the boolean value
     * if the dialog to change language was shown once. If "false" we should not prompt the change language dialog.
     */
    private val shouldShowLanguageLocaleDialog =
            InternalData(mContext).getUserPreference(InternalData.SHOULD_SHOW_LANGUAGE_SELECT_DIALOG, true)

    /**
     * @property deviceLanguageLocale keeps the value of "in-fact" device language, even when the app started.
     */
    private val deviceLanguageLocale = InternalData(mContext).getUserPreference(InternalData.DEVICE_LANGUAGE_KEY, "")

    companion object {
        // TODO tracking changes
        /**
         * @property ENGLISH_LANGUAGE_ACRONYM const value that defines the english language for the Locale
         */
        const val ENGLISH_LANGUAGE_ACRONYM = "en"

        /**
         * @property FRENCH_LANGUAGE_ACRONYM const value that defines the french language for the Locale
         */
        const val FRENCH_LANGUAGE_ACRONYM = "fr"
    }

    /**
     * this method determines if we should trigger an action if Locale Lang of the app or Device Locale
     * is not En or FR
     * @return TRUE if the language from Locale differ from "en" OR "fr"
     */
    fun shouldPromptLanguageChange(): Boolean {
        return !(userLocaleLanguage.startsWith(ENGLISH_LANGUAGE_ACRONYM, true) ||
                userLocaleLanguage.startsWith(FRENCH_LANGUAGE_ACRONYM, true)) ||
                (!(deviceLanguageLocale.startsWith(ENGLISH_LANGUAGE_ACRONYM, true) ||
                        deviceLanguageLocale.startsWith(FRENCH_LANGUAGE_ACRONYM, true)) &&
                        shouldShowLanguageLocaleDialog)
    }

    /**
     * this method gets the language locale of current context.
     * @return the string of LocaleLanguage in diff formats ex: "en", "en_CA", "fr_CA" etc...
     */
    fun getContextLanguageLocale(): String {
        val configuration = mContext.resources.configuration
        val appLanguageLocale = if (Build.VERSION.SDK_INT >= 24) configuration.locales.get(0) else configuration.locale
        return appLanguageLocale.toString()
    }

    /**
     * This method is a short version for the "updateThenSetPrefLanguage" when the Dev
     * provides only the Lang to which he wants to change.
     * @param language takes as input the String "en" or "fr" for changing the Locale Lang of the app.
     * @return Context
     */
    fun updateThenSetPrefLanguage(language: String): Context {
        return this.updateThenSetPrefLanguage(mContext, language)
    }

    /**
     * This method takes the String and Context, and makes changes to configuration of the app
     * and stores in SharedPreferences the name of Locale Lang selected by the user.
     * @param language takes as input the String "en" or "fr" for changing the Locale Lang of the app.
     * @param context the context of the application that is passed to change Locale resources.
     * @return Context
     */
    fun updateThenSetPrefLanguage(context: Context, language: String): Context {

        var localeLanguage = language
        if (localeLanguage.startsWith(FRENCH_LANGUAGE_ACRONYM)) {
            localeLanguage = FRENCH_LANGUAGE_ACRONYM
        }
        val locale = Locale(localeLanguage)
        Locale.setDefault(locale)
        val configuration = Configuration(context.resources.configuration)
        configuration.setLocale(locale)
        if (localeLanguage.startsWith(FRENCH_LANGUAGE_ACRONYM) || localeLanguage.startsWith(ENGLISH_LANGUAGE_ACRONYM)) {
            InternalData(context).storeUserPreference(InternalData.CURRENT_LANGUAGE_KEY, localeLanguage)
        }
        return context.createConfigurationContext(configuration)
    }
}
