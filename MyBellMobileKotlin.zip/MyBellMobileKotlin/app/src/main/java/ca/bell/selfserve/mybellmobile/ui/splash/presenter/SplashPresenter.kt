package ca.bell.selfserve.mybellmobile.ui.splash.presenter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.support.v4.app.LoaderManager
import ca.bell.selfserve.mybellmobile.BellApp
import ca.bell.selfserve.mybellmobile.common.*
import ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile.CustomerProfileResponse
import ca.bell.selfserve.mybellmobile.ui.splash.SplashContract
import ca.bell.selfserve.mybellmobile.ui.splash.model.ConfigurationResponse
import ca.bell.selfserve.mybellmobile.ui.splash.service.SplashInteractor
import ca.bell.selfserve.utility.AppConstant
import ca.bell.selfserve.utility.AppLog
import org.json.JSONException
import org.json.JSONObject
import java.util.*

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
 class SplashPresenter : SplashContract.ISplashPresenter, SplashInteractor.SplashInteractorCallbacks {



    private var mSplashView: SplashContract.ISplashView? = null
    private val doForceUpgrade: Boolean = false
    private var mLoaderManager: LoaderManager? = null
    private var mSplashInteractor: SplashInteractor? = null

    override val applicationLanguage: String
        get() {
            var applicationLanguage: String?
            applicationLanguage = BellApp.getInstance().getSharedPreference().getStringValue("LANGUAGE")

            if (applicationLanguage == null || "" == applicationLanguage)
                applicationLanguage = Utility.deviceLanguageFromLocale

            return applicationLanguage
        }

    override val requiredPermissionNames: HashMap<String, String>
        get() {
            val permissions = HashMap<String, String>()
            permissions.put(PermissionUtils.PermissionNames.FINE_LOCATION, PermissionUtils.PermissionValues.FINE_LOCATION)
            permissions.put(PermissionUtils.PermissionNames.COARSE_LOCATION, PermissionUtils.PermissionValues.COARSE_LOCATION)
            return permissions
        }


    override fun setAppLanguage(language: String): Boolean {
        BellApp.getInstance().getSharedPreference().setValue("LANGUAGE", language)

        AppLog.info(language + " set in configuration")
        //set language in configuration
        Configuration.getInstance().language = language

        // call to check if network is available
        checkIfNetworkIsAvailable()
        return true
    }

    override fun callConfigurationApi() {
        mSplashInteractor!!.callConfigurationApi()
    }


    override fun checkAppLanguageEnglishOrFrench(): Boolean {
        val applicationLanguage = applicationLanguage
        return AppConstant.languageNames.ENGLISH.equals(applicationLanguage) || AppConstant.languageNames.FRENCH.equals(applicationLanguage)
    }


    override fun proceedWithAppLanguage() {
        val isLanguageEnglishOrFrench = checkAppLanguageEnglishOrFrench()
        if (isLanguageEnglishOrFrench)
            setAppLanguage(applicationLanguage)
        else
            mSplashView!!.displayLanguageSelectionPopup()
    }

    /**
     * Method to check availability of location permissions
     *
     * @return true if location permission available otherwise false
     */
    override fun checkLocationPermissionAvailability(mContext: Context): Boolean {
        //return Utility.getInstance().isLocationPermissionAvailable(mContext);
        val permissionsNeeded = requiredPermissionNames
        return permissionsNeeded != null && permissionsNeeded.size > 0
    }


    override fun checkIfNetworkIsAvailable() {

        if (Utility.isNetworkAvailable(BellApp.getInstance().applicationContext)) {
            callConfigurationApi()
        } else {
            mSplashView!!.showConnectionError()
        }
    }


    override fun isForceUpgrade(configurationResponse: ConfigurationResponse): Boolean {
        val forceUpgrade = configurationResponse.androidForceUpgrade
        return forceUpgrade == "Y"
    }

    override fun goToPlayStore() {
        val appPackageName = "ca.bell.selfserve.mybellmobile" // getPackageName() from Context or Activity object
        try {
            BellApp.getInstance().getApplicationContext()?.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)))
        } catch (anfe: android.content.ActivityNotFoundException) {
            BellApp.getInstance().getApplicationContext().startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)))
        }

    }


    override fun tryAutoLogin() {
        AppLog.debug("tryAutoLogin function called.")
        val credentials = Utility.credentials
        AppLog.debug("tryAutoLogin function called credentials" + credentials!!)
        if (credentials != null) {
            try {
                val keepLogin = credentials!!.getBoolean("keepMeLogin")
                AppLog.debug("tryAutoLogin function called keepLogin" + keepLogin)
                val isProfileStillValid = Utility.isKeepMeValid(credentials!!.getString("serverTimestamp"))
                executeAutoLogin(credentials, keepLogin, isProfileStillValid)

            } catch (e: JSONException) {
                e.printStackTrace()
            }

        } else {
            mSplashView!!.showLoginScreen()
        }
    }


    private fun executeAutoLogin(jsonObject: JSONObject, keepLogin: Boolean, isProfileStillValid: Boolean) {
        if (keepLogin && isProfileStillValid) {
            var userName: String? = null
            var password: String? = null
            try {
                userName = jsonObject.getString("userName")
                password = jsonObject.getString("password")
            } catch (e: JSONException) {
                e.printStackTrace()
            }

            //            mBupAuthenticationDataManager.execute(AppConstant.userType.BUP, userName, password, this, mLoaderManager);
//            mSplashInteractor!!.authenticate(userName, password)

        } else {
            AppLog.debug("tryAutoLogin User was not auto login")
            mSplashView!!.showLoginScreen()
        }
    }

    override fun attachView(view: Any) {
        mSplashView = view as SplashContract.ISplashView

    }


    override fun detachView() {
        this.mSplashView = null
    }

    override fun attachLoader(loaderManager: LoaderManager) {
        this.mLoaderManager = loaderManager
        mSplashInteractor = SplashInteractor(this)
    }


    override fun onConfigurationResponse(configurationData: ConfigurationResponse) {

        mSplashView!!.showLoginScreen()
        /* boolean isForceUpgrade = isForceUpgrade(configurationData);
        String version = configurationData.getAndroidForceUpgradeVersion();
        String currentVersion = BuildConfig.VERSION_NAME;
        if (isForceUpgrade) {
            if (Double.parseDouble(currentVersion) < Double.parseDouble(version)) {
                AppLog.debug("Container needs to be force upgraded.");
                doForceUpgrade = true;
            }
        }

        BellApp.getInstance().getSharedPreference().setValue(ApiConstant.KEY_CONFIGURATION_RESPONSE, new Gson().toJson(configurationData));

        tryAutoLogin();*/
        /*if (doForceUpgrade) {
                    AppLog.debug("Force upgrade true. Show forceupgarde popup.");
                    mSplashView.showForceUpgradePopup(configurationData.forceUpgradeCMSContent);
                } else {
                    tryAutoLogin();
                }*/
    }


    override fun onAuthenticationSuccess(data_: Any) {
        AppLog.debug("onBupAuthenticationSuccess function called.")
        val credentials = Utility.credentials
        var userName: String? = null
        try {
            userName = credentials?.getString("userName")
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        //        mLoginService.execute(userName, this, mLoaderManager);

//        mSplashInteractor!!.requestBUPProfile()

    }

    override fun onConfigurationFailure(response: Any?) {
        checkIfNetworkIsAvailable()
    }


    override fun onAuthenticationFailure(data: Any) {
        AppLog.debug("onBupAuthenticationFail function called.")
        mSplashView!!.showLoginScreen()
    }


   override fun onBUPCustomerProfileSuccess(customerProfileResponse: CustomerProfileResponse) {
        AppLog.debug("getBUPCustomerProfileSuccess function called.")
        mSplashView!!.showLandingScreen()
    }


    override fun onBUPCustomerProfileFailure(data: Any) {
        AppLog.debug("getBUPCustomerProfileFail function called.")
        mSplashView!!.showLoginScreen()
    }

    fun onGettingException(value: Int) {

    }
}

