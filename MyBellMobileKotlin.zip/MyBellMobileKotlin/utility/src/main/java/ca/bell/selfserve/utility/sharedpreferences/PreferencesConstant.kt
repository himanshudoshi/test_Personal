package ca.bell.selfserve.mybellmobile.sharedpreferences

/**
 * Created by Gaurav Gupta on 5/1/2018.
 */
class PreferencesConstant {

    companion object {
        val PREFERENCES_NAME = "bell_preference"
    }

}
