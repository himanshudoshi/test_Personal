package ca.bell.selfserve.mybellmobile

import android.app.Application
import android.os.SystemClock

import java.io.File

import ca.bell.selfserve.data.DataSingleton
import ca.bell.selfserve.utility.AppConstant
import ca.bell.selfserve.mybellmobile.common.Configuration
import ca.bell.selfserve.mybellmobile.common.SessionManager

import ca.bell.selfserve.mybellmobile.sharedpreferences.SharedPreferenceManager
//import ca.bell.selfserve.mybellmobile.webview.AppWebView


class BellApp : Application() {

//    var appWebView: AppWebView? = null

    /**
     * method to return shared preferences object
     *
     * @return
     */
    private lateinit  var sharedPreference: SharedPreferenceManager

    fun getSharedPreference():SharedPreferenceManager{
        return sharedPreference
    }


    private lateinit var deviceConfiguration: Configuration
    private val session = SessionManager()



    public fun getSessionManager():SessionManager{
        return session
    }



    override fun onCreate() {
        super.onCreate()
        _instance = this

        clearApplicationData()

        // initialize shared preferences
        sharedPreference = SharedPreferenceManager.getInstance(applicationContext)

        if (!sharedPreference.hasData(AppConstant.SharedPrefrencesConstants.APPLICATION_INSTALLATION_TIME)) {
            val installationTime = SystemClock.currentThreadTimeMillis().toString()
            sharedPreference.setValue(AppConstant.SharedPrefrencesConstants.APPLICATION_INSTALLATION_TIME, installationTime)
        }

        // initialize configuration class
        deviceConfiguration = Configuration.getInstance()

        DataSingleton.init(this)
        DataSingleton.getDataSingleton().applicationName = Configuration.getInstance().applicationName
        //loading hybrid webview in background
//        Utility.startLoadingWebAppInBackground(this)

    }


    fun clearApplicationData() {
        val cacheDirectory = cacheDir
        val applicationDirectory = File(cacheDirectory.parent)
        if (applicationDirectory.exists()) {
            val fileNames = applicationDirectory.list()
            for (fileName in fileNames) {
                if (fileName != "lib") {
                    deleteFile(File(applicationDirectory, fileName))
                }
            }
        }
    }

    fun deleteFile(file: File?): Boolean {
        var deletedAll = true
        if (file != null) {
            if (file.isDirectory) {
                val children = file.list()
                for (i in children.indices) {
                    deletedAll = deleteFile(File(file, children[i])) && deletedAll
                }
            } else {
                deletedAll = file.delete()
            }
        }
        return deletedAll
    }




    /*public fun getSharedPreferenceManager(): SharedPreferenceManager {
        return sharedPreference as SharedPreferenceManager
    }
*/
    companion object {
        private lateinit var  _instance: BellApp


        public fun getInstance():BellApp{
            return _instance
        }

    }

}
