package ca.bell.nmf.ui.view

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Build
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.util.TypedValue
import android.widget.TextView
import ca.bell.nmf.ui.R

/**
 * @AlertDialogView provides three methods to show alert dialog with single/double/triple action button
 * @showSingleButtonDialog alert dialog with single action button
 * @showDoubleButtonDialog alert dialog with two action button
 * @showTripleButtonDialog alert dialog with three action button
 */
class AlertDialogView {
    /**
     *  create and show dialog with single action button
     *  @param context activity context
     *  @param title set title
     *  @param message set message
     *  @param positiveButtonText set positive button text
     *  @param positiveButtonClick positive button callback
     *  @param isCancelableOnTouchOutside set dialog cancelable property, by default not cancelable
     */
    fun showSingleButtonDialog(context: Context, title: String, message: String,
                               positiveButtonText: String, positiveButtonClick: DialogInterface.OnClickListener,
                               isCancelableOnTouchOutside: Boolean = false) {
        val alertDialogBuilder = AlertDialog.Builder(context, R.style.NMF_Styles_AlertDialog_Default)
        if (title.isNotEmpty())
            alertDialogBuilder.setTitle(title)
        if (message.isNotEmpty())
            alertDialogBuilder.setMessage(message)
        if (positiveButtonText.isNotEmpty())
            alertDialogBuilder.setPositiveButton(positiveButtonText, positiveButtonClick)
        alertDialogBuilder.setCancelable(isCancelableOnTouchOutside)

        val alertDialog: Dialog = alertDialogBuilder.create()
        alertDialog.show()
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            alertDialog.window.setElevation(60f)
        }

        val textViewMessage = alertDialog.findViewById(android.R.id.message) as TextView
        textViewMessage.setTextColor(ContextCompat.getColor(context, R.color.default_text_color))
        textViewMessage.setTextSize(TypedValue.COMPLEX_UNIT_PX, context.resources.getDimension(R.dimen.text_size_medium))
        textViewMessage.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5.0f, context.resources.displayMetrics), 1.0f)
    }


    /**
     *  create and show dialog with two action button
     *  @param context activity context
     *  @param title set title
     *  @param message set message
     *  @param positiveButtonText set positive button text
     *  @param positiveButtonClick positive button callback
     *  @param negativeButtonText set negative button text
     *  @param negativeButtonClick negative button callback
     *  @param isCancelableOnTouchOutside set dialog cancelable property, by default not cancelable
     */
    fun showDoubleButtonDialog(context: Context, title: String, message: String,
                               positiveButtonText: String, positiveButtonClick: DialogInterface.OnClickListener,
                               negativeButtonText: String, negativeButtonClick: DialogInterface.OnClickListener,
                               isCancelableOnTouchOutside: Boolean = false) {
        val alertDialogBuilder = AlertDialog.Builder(context, R.style.NMF_Styles_AlertDialog_Default)
        if (title.isNotEmpty())
            alertDialogBuilder.setTitle(title)
        if (message.isNotEmpty())
            alertDialogBuilder.setMessage(message)
        if (positiveButtonText.isNotEmpty())
            alertDialogBuilder.setPositiveButton(positiveButtonText, positiveButtonClick)
        if (negativeButtonText.isNotEmpty())
            alertDialogBuilder.setNegativeButton(negativeButtonText, negativeButtonClick)
        alertDialogBuilder.setCancelable(isCancelableOnTouchOutside)

        val alertDialog: Dialog = alertDialogBuilder.create()
        alertDialog.show()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            alertDialog.window.setElevation(60f)
        }

        val textViewMessage = alertDialog.findViewById(android.R.id.message) as TextView
        textViewMessage.setTextColor(ContextCompat.getColor(context, R.color.default_text_color))
        textViewMessage.setTextSize(TypedValue.COMPLEX_UNIT_PX, context.resources.getDimension(R.dimen.text_size_medium))
        textViewMessage.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5.0f, context.resources.displayMetrics), 1.0f)
    }


    /**
     *  create and show dialog with three action button
     *  @param context activity context
     *  @param title set title
     *  @param message set message
     *  @param positiveButtonText set positive button text
     *  @param positiveButtonClick positive button callback
     *  @param negativeButtonText set negative button text
     *  @param negativeButtonClick negative button callback
     *  @param neutralButtonText set neutral button text
     *  @param neutralButtonClick neutral button callback
     *  @param isCancelableOnTouchOutside set dialog cancelable property, by default not cancelable
     */
    fun showTripleButtonDialog(context: Context, title: String, message: String,
                               positiveButtonText: String, positiveButtonClick: DialogInterface.OnClickListener,
                               negativeButtonText: String, negativeButtonClick: DialogInterface.OnClickListener,
                               neutralButtonText: String, neutralButtonClick: DialogInterface.OnClickListener,
                               isCancelableOnTouchOutside: Boolean = false) {
        val alertDialogBuilder = AlertDialog.Builder(context, R.style.NMF_Styles_AlertDialog_Default)
        if (title.isNotEmpty())
            alertDialogBuilder.setTitle(title)
        if (message.isNotEmpty())
            alertDialogBuilder.setMessage(message)
        if (positiveButtonText.isNotEmpty())
            alertDialogBuilder.setPositiveButton(positiveButtonText, positiveButtonClick)
        if (negativeButtonText.isNotEmpty())
            alertDialogBuilder.setNegativeButton(negativeButtonText, negativeButtonClick)
        if (neutralButtonText.isNotEmpty())
            alertDialogBuilder.setNeutralButton(neutralButtonText, neutralButtonClick)
        alertDialogBuilder.setCancelable(isCancelableOnTouchOutside)

        val alertDialog: Dialog = alertDialogBuilder.create()
        alertDialog.show()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            alertDialog.window.setElevation(60f)
        }

        val textViewMessage = alertDialog.findViewById(android.R.id.message) as TextView
        textViewMessage.setTextColor(ContextCompat.getColor(context, R.color.default_text_color))
        textViewMessage.setTextSize(TypedValue.COMPLEX_UNIT_PX, context.resources.getDimension(R.dimen.text_size_medium))
        textViewMessage.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5.0f, context.resources.displayMetrics), 1.0f)
    }

}
