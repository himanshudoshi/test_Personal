package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class CreditInfo(

        @field:SerializedName("creditClass")
        val creditClass: CreditClass? = null,

        @field:SerializedName("creditScore")
        val creditScore: String? = null,

        @field:SerializedName("creditScoreType")
        val creditScoreType: Any? = null
)