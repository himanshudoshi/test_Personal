package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

import com.google.gson.annotations.SerializedName

data class CustomerProfileResponse(

        @field:SerializedName("data")
        val data: Data? = null,

        @field:SerializedName("responseHeader")
        val responseHeader: ResponseHeader? = null,

        @field:SerializedName("error")
        val error: Any? = null
)