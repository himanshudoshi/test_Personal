package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

import com.google.gson.annotations.SerializedName

data class Data(

        @field:SerializedName("appStoreRedirectVirginFlag")
        val appStoreRedirectVirginFlag: Boolean? = null,

        @field:SerializedName("isNgccWithRest")
        val isNgccWithRest: Boolean? = null,

        @field:SerializedName("appStoreRedirectBellFlag")
        val appStoreRedirectBellFlag: Boolean? = null,

        @field:SerializedName("customerProfile")
        val customerProfile: CustomerProfile? = null,

        @field:SerializedName("isMultilineEnabled")
        val isMultilineEnabled: Boolean? = null,

        @field:SerializedName("outages")
        val outages: Any? = null,

        @field:SerializedName("sessionToken")
        val sessionToken: String? = null,

        @field:SerializedName("isViewBillEnabled")
        val isViewBillEnabled: Boolean? = null,

        @field:SerializedName("appStoreRedirectFlag")
        val appStoreRedirectFlag: Boolean? = null,

        @field:SerializedName("noOfDays")
        val noOfDays: Int? = null,

        @field:SerializedName("noOfLaunches")
        val noOfLaunches: Int? = null
)