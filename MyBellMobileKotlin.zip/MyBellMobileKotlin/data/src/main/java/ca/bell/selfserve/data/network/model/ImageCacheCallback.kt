package ca.bell.selfserve.data.network.model

import android.graphics.Bitmap

/**
 * Created by GG00539076 on 4/10/2018.
 */

interface ImageCacheCallback {
    fun invalidUrl(url: String)
    fun onBitmapLoaded(url: String, bitmap: Bitmap)
    fun onError(message: String)
}
