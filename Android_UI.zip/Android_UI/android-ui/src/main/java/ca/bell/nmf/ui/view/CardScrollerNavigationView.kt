package ca.bell.nmf.ui.view

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import ca.bell.nmf.ui.R

class CardScrollerNavigationView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyle: Int = 0,
        defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyle, defStyleRes) {

    init {
        LayoutInflater.from(context).inflate(R.layout.component_card_scroller_navigation, this, true)
        orientation = HORIZONTAL
    }

    fun initUI(nbElements: Int) {
        val radioGroup = findViewById<View>(R.id.card_navigation_radio_group) as RadioGroup
        val iterator = (0 until nbElements).iterator()
        iterator.forEach { element ->
            val button = RadioButton(context)
            button.id = element
            button.setButtonDrawable(R.drawable.component_card_scroller_navigation_selector)
            button.setPadding(resources.getDimension(R.dimen.padding_margin)as Int, 0, resources.getDimension(R.dimen.padding_margin)as Int, 0)
            radioGroup.addView(button)
        }
    }

    fun selectElement(index: Int) {
        val radioGroup = findViewById<View>(R.id.card_navigation_radio_group) as RadioGroup
        radioGroup.check(index)
    }

}
