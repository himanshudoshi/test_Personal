package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class BillingAddress(

        @field:SerializedName("apartmentNo")
        val apartmentNo: Any? = null,

        @field:SerializedName("country")
        val country: String? = null,

        @field:SerializedName("secondaryLine")
        val secondaryLine: Any? = null,

        @field:SerializedName("streetType")
        val streetType: Any? = null,

        @field:SerializedName("isManualOverride")
        val isManualOverride: Any? = null,

        @field:SerializedName("inCareOf")
        val inCareOf: Any? = null,

        @field:SerializedName("city")
        val city: String? = null,

        @field:SerializedName("addressType")
        val addressType: AddressType? = null,

        @field:SerializedName("postalCode")
        val postalCode: String? = null,

        @field:SerializedName("civicNum")
        val civicNum: Any? = null,

        @field:SerializedName("deliveryType")
        val deliveryType: Any? = null,

        @field:SerializedName("deliveryTypeSuffix")
        val deliveryTypeSuffix: Any? = null,

        @field:SerializedName("civicNumSuffix")
        val civicNumSuffix: Any? = null,

        @field:SerializedName("dwellingType")
        val dwellingType: Any? = null,

        @field:SerializedName("designatorSuffix")
        val designatorSuffix: Any? = null,

        @field:SerializedName("room")
        val room: Any? = null,

        @field:SerializedName("streetDirection")
        val streetDirection: Any? = null,

        @field:SerializedName("primaryLine")
        val primaryLine: String? = null,

        @field:SerializedName("streetName")
        val streetName: Any? = null,

        @field:SerializedName("province")
        val province: Province? = null,

        @field:SerializedName("areaName")
        val areaName: Any? = null,

        @field:SerializedName("modeOfDelivery")
        val modeOfDelivery: Any? = null,

        @field:SerializedName("modeDeliverySuffix")
        val modeDeliverySuffix: Any? = null,

        @field:SerializedName("state")
        val state: Any? = null
)