package ca.bell.nmf.ui.view


import android.content.Context
import android.graphics.Typeface
import android.os.OperationCanceledException
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.util.AttributeSet
import android.view.Menu
import android.view.MenuItem
import android.view.SubMenu
import android.view.View
import android.widget.TextView
import ca.bell.nmf.ui.R


/**
 * Created on 7/24/2018.
 */
class ShortHeaderTopbar : Toolbar {

    /**
     * toolbar.title does not change title if we call it before activity.setSupportActionBar().
     * So for this local variable mTitle is used, which will automatically set title after activity.setSupportActionBar() is called
     * in method setSupportActionBar(activity: AppCompatActivity) method.
     */
    private var mTitle: CharSequence = ""


    /**
     * Submenu is used to inflate menu with both title & text.
     *
     */
    private var mSubMenu: SubMenu? = null


    /**
     * When inflateMenu method is called, it will send callback to the calling class by calling onTopbarReady() of this object.
     */
    var shortHeaderTopbarCallback: ShortHeaderTopbarCallback? = null


    companion object {


        /**
         * Error sent to calling class when no title & image passed while adding menu
         */
        private const val ERROR_NO_IMAGE_AND_TITLE_FOUND = "Please send atleast one from title and image to add menu item";


        /**
         * The index of title TextView from TextView childs after it is initialised on init is 0
         */
        const val TITLE_INDEX: Int = 0


        /**
         * The index of subtitle TextView from TextView childs after it is initialised on init  is 1
         */
        const val SUBTITLE_INDEX: Int = 1

    }

    constructor(context: Context) : super(context) {
        onInit()
    }


    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        onInit()
    }

    constructor (context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        onInit()
    }

    /**
     * sets primary text color to actionbar
     */
    private fun onInit() {
        setBackgroundColor(ContextCompat.getColor(context, R.color.colorPrimary))
    }


    /**
     * it sets title text of toolbar
     */
    override fun setTitle(title: CharSequence?) {
        if (title != null)
            mTitle = title
        super.setTitle(title)
    }

    /**
     * It set support actionbar. After setting it, changes title text
     */
    fun setSupportActionBar(activity: AppCompatActivity) {
        activity.setSupportActionBar(this)

        /**
         * By default title text is set so that we can get title textview in project
         */
        title = " "
        activity.supportActionBar!!.title = " "


        /**
         * By default subtitle text is set so that we can get subtitle textview in project
         */
        subtitle = " "
        activity.supportActionBar!!.subtitle = " "

        if (!mTitle.isBlank())
            activity.supportActionBar!!.title = mTitle

    }

    /**
     * By calling this method, dev can create menu without using actual menu resource
     */
    fun inflateMenu() {
        super.inflateMenu(R.menu.empty_menu)
        val subMenu: SubMenu = menu!!.findItem(R.id.more).subMenu
        setSubMenu(subMenu)

        if (shortHeaderTopbarCallback != null)
            shortHeaderTopbarCallback!!.onTopbarReady()
    }

    /**
     * dev can create menu with using menu resource
     */
    override fun inflateMenu(resId: Int) {
        super.inflateMenu(resId)

        if (shortHeaderTopbarCallback != null)
            shortHeaderTopbarCallback!!.onTopbarReady()
    }


    /***
     * It set submenu for adding items
     */
    fun setSubMenu(submenu: SubMenu?) {
        mSubMenu = submenu
    }


    /**
     * This method is used to add the MenuItem in actionbar's menu / submenu
     * @param itemId = itemId of MenuItem
     * @param image = image resource id
     * @param title = Title text
     * @param showAsAction= 'true' if menuItem is required, 'false' if submenuItem is required
     * @order
     */
    fun addMenuItem(itemId: Int, title: String = "", image: Int = -1, showAsAction: Boolean, groupId: Int = 0)
    {
        val noImageReceived: Boolean = image == -1
        val noTextReceived: Boolean = title == ""

        if (noImageReceived && noTextReceived) {
            throw OperationCanceledException(ERROR_NO_IMAGE_AND_TITLE_FOUND)
        }

        lateinit var menuItem: MenuItem

        if (showAsAction) {
            menuItem = menu!!.add(groupId, itemId, Menu.NONE, title)
        } else {
            menuItem = mSubMenu!!.add(groupId, itemId, Menu.NONE, title)
        }



        if (!noImageReceived)
            menuItem.setIcon(image)

        menuItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)

    }


    /**
     * This method is used to remove MenuItem from the menu from actionbar's menu/submenu
     * @param itemId: id of MenuItem
     */
    fun removeMenuItem(itemId: Int) {
        try {
            val mi: MenuItem? = menu!!.findItem(itemId)
            if (mi != null)
                menu.removeItem(itemId)
        } catch (e: ArrayIndexOutOfBoundsException) {
            e.printStackTrace()
        }


        try {
            val mi: MenuItem? = mSubMenu!!.findItem(itemId)
            if (mi != null)
                mSubMenu!!.removeItem(itemId)
        } catch (e: ArrayIndexOutOfBoundsException) {
            e.printStackTrace()
        }

    }


    /**
     * It changes font style of Title & Subtitle
     *
     * @param : Typeface for font style
     */
    fun setTypeface(typeface: Typeface) {
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            // assuming that the title is the first instance of TextView
            // you can also check if the title string matches
            if (child is TextView) {
                child.typeface = typeface
            }
        }
    }

    /**
     * returns textview child in toolbar at mentioned index, if no textview child is found, it returns null.
     */
    fun getTextViewChildAtIndex(index: Int): TextView? {
        var counter = 0
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child is TextView) {
                counter += 1
                if (index == (counter - 1)) {
                    return child
                }

            }
        }
        return null
    }


    /**
     * This function takes item id of menuitem, and returns if its TextView else return null
     *
     * @itemId: Id of the TextView item
     */
    fun getTextViewMenuItem(itemId: Int): TextView? {
        val view = findViewById<View?>(itemId)
        // Cast to a TextView instance if the menu item was found
        if (view != null && view is TextView)
            return view
        else return null
    }


    /**
     * Sets the TextColor of textview at index 'n'
     */
    fun setTextColor(itemId: Int, color: Int): Boolean {
        val textViewMenuItem: TextView? = getTextViewMenuItem(itemId)
        if (textViewMenuItem != null) {
            textViewMenuItem.setTextColor(color)
            return true
        }
        return false
    }


    /***
     * Interface to get onTopbarReadycallback
     */
    interface ShortHeaderTopbarCallback {

        /***
         * after inflate is called, onTopbarReady is  called.
         */
        fun onTopbarReady()
    }
}