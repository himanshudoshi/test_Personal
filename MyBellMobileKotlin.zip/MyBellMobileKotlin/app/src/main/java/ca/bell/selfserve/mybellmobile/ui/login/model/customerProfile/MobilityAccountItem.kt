package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

public data class MobilityAccountItem(

        @field:SerializedName("currentCycleEndDate")
        val currentCycleEndDate: Long? = null,

        @field:SerializedName("lastUpdateStamp")
        val lastUpdateStamp: Int? = null,

        @field:SerializedName("accountCommPref")
        val accountCommPref: Any? = null,

        @field:SerializedName("contractDistributionInfo")
        val contractDistributionInfo: ContractDistributionInfo? = null,

        @field:SerializedName("lastUpdateDate")
        val lastUpdateDate: Long? = null,

        @field:SerializedName("logicalCurrentDate")
        val logicalCurrentDate: Long? = null,

        @field:SerializedName("language")
        val language: Language? = null,

        @field:SerializedName("arpuamount")
        val arpuamount: String? = null,

        @field:SerializedName("responseCode")
        val responseCode: Any? = null,

        @field:SerializedName("accountHolder")
        val accountHolder: String? = null,

        @field:SerializedName("isPrepaid")
        val isPrepaid: Boolean? = null,

        @field:SerializedName("emailAddress")
        val emailAddress: String? = null,

        @field:SerializedName("responseStatusDescription")
        val responseStatusDescription: String? = null,

        @field:SerializedName("responseVersion")
        val responseVersion: String? = null,

        @field:SerializedName("authorizedContactName1")
        val authorizedContactName1: Any? = null,

        @field:SerializedName("contactAddress")
        val contactAddress: ContactAddress? = null,

        @field:SerializedName("consoAccountNo")
        val consoAccountNo: String? = null,

        @field:SerializedName("isBillSuppressed")
        val isBillSuppressed: Boolean? = null,

        @field:SerializedName("authorizedContactName2")
        val authorizedContactName2: Any? = null,

        @field:SerializedName("nextCycleStartDate")
        val nextCycleStartDate: Long? = null,

        @field:SerializedName("creditInfo")
        val creditInfo: CreditInfo? = null,

        @field:SerializedName("contactTelephone")
        val contactTelephone: Any? = null,

        @field:SerializedName("isInCollection")
        val isInCollection: Boolean? = null,

        @field:SerializedName("subscribers")
        val subscribers: Subscribers? = null,

        @field:SerializedName("accountType")
        val accountType: AccountType? = null,

        @field:SerializedName("submarket")
        val submarket: Submarket? = null,

        @field:SerializedName("responseStatus")
        val responseStatus: String? = null,

        @field:SerializedName("consoStatus")
        val consoStatus: ConsoStatus? = null,

        @field:SerializedName("organizationID")
        val organizationID: String? = null,

        @field:SerializedName("otherIdentifiers")
        val otherIdentifiers: OtherIdentifiers? = null,

        @field:SerializedName("isAccountSMSPerm")
        val isAccountSMSPerm: Boolean? = null,

        @field:SerializedName("paymentMethod")
        val paymentMethod: PaymentMethod? = null,

        @field:SerializedName("ebillInfo")
        val ebillInfo: EbillInfo? = null,

        @field:SerializedName("spendingCapsUsed")
        val spendingCapsUsed: SpendingCapsUsed? = null,

        @field:SerializedName("backendResponseCode")
        val backendResponseCode: Any? = null,

        @field:SerializedName("heldDepositeAmount")
        val heldDepositeAmount: Double? = null,

        @field:SerializedName("accountName")
        val accountName: String? = null,

        @field:SerializedName("accountSubType")
        val accountSubType: AccountSubType? = null,

        @field:SerializedName("accountStatusReason")
        val accountStatusReason: String? = null,

        @field:SerializedName("accountStatus")
        val accountStatus: String? = null,

        @field:SerializedName("billingAddressUpdateDate")
        val billingAddressUpdateDate: Long? = null,

        @field:SerializedName("nickname")
        val nickname: String? = null,

        @field:SerializedName("billingName")
        val billingName: String? = null,

        @field:SerializedName("cancelledAcctStatusDate")
        val cancelledAcctStatusDate: Any? = null,

        @field:SerializedName("marketSegment")
        val marketSegment: MarketSegment? = null,

        @field:SerializedName("spendingCaps")
        val spendingCaps: SpendingCaps? = null,

        @field:SerializedName("consolidationSystem")
        val consolidationSystem: Any? = null,

        @field:SerializedName("accountNumber")
        val accountNumber: String? = null,

        @field:SerializedName("siowner")
        val siowner: Siowner? = null,

        @field:SerializedName("visibilityLevel")
        val visibilityLevel: String? = null,

        @field:SerializedName("arbalance")
        val arbalance: Arbalance? = null,

        @field:SerializedName("linkType")
        val linkType: String? = null,

        @field:SerializedName("billingAddress")
        val billingAddress: BillingAddress? = null,

        @field:SerializedName("billCycleCode")
        val billCycleCode: Int? = null,

        @field:SerializedName("isEcareRegistered")
        val isEcareRegistered: Boolean? = null
)