package ca.bell.selfserve.mybellmobile.common

import ca.bell.selfserve.mybellmobile.base.ExceptionHandlerInterface
import ca.bell.selfserve.utility.AppConstant


/*This is the custom class which is created for NSI authentication and switching.*/
class ErrorHandler {
    fun handleAuthenticationFailure(exceptionHandlerInterface: ExceptionHandlerInterface, response: Any) {
        //        Resources resources = mContext.getResources();
        val responseCode = response as Int
        /*Following are authentication failures for BUP cases.*/
        when (responseCode) {

            AppConstant.ApiErrorCodes.ERROR_124 -> exceptionHandlerInterface.onGettingException(AppConstant.ApiErrorCodes.ERROR_124)
            AppConstant.ApiErrorCodes.ERROR_505 -> exceptionHandlerInterface.onGettingException(AppConstant.ApiErrorCodes.ERROR_505)
            AppConstant.ApiErrorCodes.ERROR_133 -> exceptionHandlerInterface.onGettingException(AppConstant.ApiErrorCodes.ERROR_133)
            AppConstant.ApiErrorCodes.ERROR_205 -> exceptionHandlerInterface.onGettingException(AppConstant.ApiErrorCodes.ERROR_205)

        // TODO: 9/19/2017 outage is pending
            AppConstant.ApiErrorCodes.ERROR_232 -> exceptionHandlerInterface.onGettingException(AppConstant.ApiErrorCodes.ERROR_232)
        // TODO: 9/19/2017 outage is pending
            AppConstant.ApiErrorCodes.ERROR_233 -> exceptionHandlerInterface.onGettingException(AppConstant.ApiErrorCodes.ERROR_233)
        }/*Utility.showErrorSingleButton(mContext, resources.getString(R.string.login_nsiAuthFailedTitle),
                        resources.getString(R.string.login_netAuthFailed), resources.getString(R.string.close));*/
        /* Utility.showErrorSingleButton(mContext, resources.getString(R.string.login_netError),
                        resources.getString(R.string.login_netConnectionFailed), resources.getString(R.string.close));*//*Utility.showErrorSingleButton(mContext, resources.getString(R.string.login_prepaidUnSupportedTitle),
                        resources.getString(R.string.login_prepaidUnSupportedMsg), resources.getString(R.string.close));*//* Utility.showErrorSingleButton(mContext, resources.getString(R.string.login_accountLocked),
                        resources.getString(R.string.login_accountLockedFullMsg), resources.getString(R.string.close));*//* Utility.showErrorSingleButton(mContext, resources.getString(R.string.login_netError),
                        resources.getString(R.string.login_netConnectionFailed), resources.getString(R.string.close));*//* Utility.showErrorSingleButton(mContext, resources.getString(R.string.login_netError),
                        resources.getString(R.string.login_netConnectionFailed), resources.getString(R.string.close));*/
    }


}
