package ca.bell.selfserve.data.network.model

/**
 * Created by GG00539076 on 5/22/2018.
 */

enum class NetworkType{
    WIFI, CELLULAR, NO_NETWORK
}