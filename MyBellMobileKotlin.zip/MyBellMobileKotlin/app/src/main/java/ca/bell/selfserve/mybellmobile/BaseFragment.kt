package ca.bell.selfserve.mybellmobile.base

import android.support.v4.app.Fragment

/**
 * Created by Gaurav Gupta on 5/1/2018.
 * base class of all fragment
 */
class BaseFragment : Fragment()