package ca.bell.selfserve.mybellmobile.ui.splash.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
class ConfigurationResponse {

    @SerializedName("Android_ForceUpgrade")
    @Expose
    var androidForceUpgrade: String? = null
    @SerializedName("Android_ForceUpgrade_Version")
    @Expose
    var androidForceUpgradeVersion: String? = null
    @SerializedName("iOS_ForceUpgrade")
    @Expose
    private var iOSForceUpgrade: String? = null
    @SerializedName("iOS_ForceUpgrade_Version")
    @Expose
    private var iOSForceUpgradeVersion: String? = null
    @SerializedName("forceUpgradeCMSContent")
    @Expose
    var forceUpgradeCMSContent: List<ForceUpgradeCMSContent>? = null
    @SerializedName("appFlags")
    @Expose
    var appFlags: List<AppFlag>? = null

    fun getiOSForceUpgrade(): String? {
        return iOSForceUpgrade
    }

    fun setiOSForceUpgrade(iOSForceUpgrade: String) {
        this.iOSForceUpgrade = iOSForceUpgrade
    }

    fun getiOSForceUpgradeVersion(): String? {
        return iOSForceUpgradeVersion
    }

    fun setiOSForceUpgradeVersion(iOSForceUpgradeVersion: String) {
        this.iOSForceUpgradeVersion = iOSForceUpgradeVersion
    }
}
