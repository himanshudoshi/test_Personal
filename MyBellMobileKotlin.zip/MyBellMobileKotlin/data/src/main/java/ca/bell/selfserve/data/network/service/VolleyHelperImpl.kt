package ca.bell.selfserve.data.network.service

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import android.util.LruCache
import ca.bell.selfserve.data.network.model.NetworkModel
import ca.bell.selfserve.data.network.model.ImageCacheCallback

import java.io.UnsupportedEncodingException
import java.util.HashMap

import com.android.volley.*
import com.android.volley.toolbox.*

/**
 * Created by GG00539076 on 4/3/2018.
 */

class VolleyHelperImpl(context: Context) {

    val requestQueue: RequestQueue
    private val TIMEOUT = 3500
    private val MAX_RETRY_ATTEMPT = 4
    private val SIZE_CACHE = 2000


    private val loader: ImageLoader
        get() = ImageLoader(requestQueue,
                object : ImageLoader.ImageCache {
                    private val cache = LruCache<String, Bitmap>(SIZE_CACHE)

                    override fun getBitmap(url: String): Bitmap {
                        return cache.get(url)
                    }

                    override fun putBitmap(url: String, bitmap: Bitmap) {
                        cache.put(url, bitmap)
                    }
                })




    init {
        requestQueue = Volley.newRequestQueue(context)
    }


    fun execute(modelVolley: NetworkModel
                , stringListener: VolleyStringListener
                , errorListener: Response.ErrorListener
                , retryErrorListener: RetryErrorListener

    ) {
        val stringRequest: StringRequest

        stringRequest = getRequestWRT(modelVolley, stringListener, errorListener)
        stringRequest.tag = modelVolley.getTag()

        if (modelVolley.IsRetryIfFail()) {
            /**
             * The below code is useful but its commented to implement custom retry
             */
            //            RetryPolicy retryPolicy = new DefaultRetryPolicy();
            val retryPolicy = getMyRetryPolicy(TIMEOUT, MAX_RETRY_ATTEMPT, retryErrorListener)

            stringRequest.retryPolicy = retryPolicy
        }


        requestQueue.add(stringRequest)
    }


    private fun getMyRetryPolicy(timeoutMS: Int, retryCount: Int, retryErrorListener: RetryErrorListener): RetryPolicy {
        return object : RetryPolicy {
            override fun getCurrentTimeout(): Int {
                return timeoutMS
            }

            override fun getCurrentRetryCount(): Int {
                return retryCount
            }

            @Throws(VolleyError::class)
            override fun retry(error: VolleyError) {
                retryErrorListener.onErrorWhileRetry(error)
            }
        }
    }

    private fun getRequestWRT(modelVolley: NetworkModel
                              , stringListener: VolleyStringListener
                              , errorListener: Response.ErrorListener
    )
            : StringRequest {

        Log.e("method", Request.Method.POST.toString() + "," + modelVolley.getMethod())

        return object : StringRequest(modelVolley.getMethod(), getCompleteNetworkUrl(modelVolley.getNetworkURL(), modelVolley.getQueryParams()),
                stringListener,
                errorListener) {


            override fun parseNetworkResponse(response: NetworkResponse?): Response<String> {

                var headers: HashMap<String, ArrayList<String>> = HashMap();

                if (response!=null)
                {
                    var headers_: List<Header> = response.allHeaders
                    for (header in headers_) {
                        var key = header.name
                        var value = header.value
                        var isHeaderExits = headers.containsKey(key)
                        var list: ArrayList <String> = ArrayList<String>();

                        if (isHeaderExits) {
                            list = headers.get(key)!!
                        }

                        list.add(value)
                        headers.put(key,list)
                    }
                }

                stringListener.onHeadersReceived(headers )

                return super.parseNetworkResponse(response)
            }

            override fun getPriority(): Request.Priority {

                if (modelVolley.getPriority() == null) {
                    return super.getPriority()
                }
                when (modelVolley.getPriority()) {

                    Priority.LOW -> return Request.Priority.LOW

                    Priority.IMMEDIATE -> return Request.Priority.IMMEDIATE

                    Priority.NORMAL -> return Request.Priority.NORMAL

                    Priority.HIGH -> return Request.Priority.HIGH

                    else -> return Request.Priority.NORMAL
                }
            }


            @Throws(AuthFailureError::class)
            override fun getBody(): ByteArray? {

                val body = modelVolley.getBodyParameters().toString()
                val encoding = "utf-8"

                try {
                    return body?.toByteArray(charset(encoding))
                } catch (uee: UnsupportedEncodingException) {
                    val error = "Unsupported Encoding while trying to get the bytes of %s using %s"
                    VolleyLog.wtf(error, body, encoding)
                    return null
                }

            }


            @Throws(AuthFailureError::class)
            override fun getHeaders(): Map<String, String>? {
                val headers = modelVolley.getHeaderParams()
                return headers ?: super.getHeaders()
            }

            override fun getBodyContentType(): String {
                return "application/json; charset=utf-8"
            }


        }
    }

    private fun getCompleteNetworkUrl(networkURL: String?, queryParams: HashMap<String, String>?): String? {

        if (queryParams == null || queryParams.isEmpty()) {
            return networkURL
        }

        val stringBuffer = StringBuffer()
        stringBuffer.append(networkURL)
        stringBuffer.append("?")
        val keys = queryParams.keys
        val stringIterator = keys.iterator()



        for (i in keys.indices) {
            if (i > 0) {
                stringBuffer.append("&")
            }
            val key = stringIterator.next()
            stringBuffer.append(key + "=" + queryParams[key])
        }
        return stringBuffer.toString()
    }


    fun cancelAll(tag: Any) {
        requestQueue.cancelAll(tag)
    }

    fun loadImage(url: String, imageLoaderCallback: ImageCacheCallback) {
        if (url == "") {
            imageLoaderCallback.invalidUrl(url)
            return
        }
        // Retrieves an image specified by the URL, displays it in the UI.
        val request = ImageRequest(
                url
                , object : Response.Listener<Bitmap> {
            override fun onResponse(response: Bitmap) {
                imageLoaderCallback.onBitmapLoaded(url, response)
            }
        }
                , 0
                , 0
                , null
                , object : Response.ErrorListener {
            override fun onErrorResponse(error: VolleyError) {
                if (error.message == null) {
                    imageLoaderCallback.onError("Error in bitmap")
                } else {
                    imageLoaderCallback.onError(error.message!!)
                }
            }
        }
        )
        // Access the RequestQueue through your singleton class.
        requestQueue.add(request)
    }

    fun loadImage(url: String, networkImageView: NetworkImageView) {
        val mImageLoader = loader
        networkImageView.setImageUrl(url, mImageLoader
        )
    }

    fun clearCache() {
        requestQueue.cache.clear();
    }

    fun clearCache(key: String) {
        requestQueue.cache.remove(key)
    }

    fun cancelRequest(key: String) {
        requestQueue.cancelAll(key)
    }
}

interface RetryErrorListener {
    fun onErrorWhileRetry(e: Exception)
}

interface VolleyStringListener : Response.Listener<String> {
    fun onHeadersReceived(headers: Map<String, ArrayList<String>>);
}
