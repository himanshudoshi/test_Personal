package ca.bell.selfserve.data.network.api

import android.annotation.SuppressLint
import android.util.Base64
import ca.bell.selfserve.data.DataSingleton
import ca.bell.selfserve.data.network.model.*
import ca.bell.selfserve.data.network.service.ApiRestCall
import ca.bell.selfserve.utility.AppConstant
import ca.bell.selfserve.utility.AppLog
import com.google.gson.JsonObject
import java.io.UnsupportedEncodingException
import java.net.URLEncoder
import java.util.HashMap


/**
 * Created by AU00538779 on 5/23/2018.
 */
class LoginAPI{


    fun performLogin(authType: String, userName: String, password: String, serviceStringForProfile : String
                     , loginCallback: NetworkBaseCallback) {
        val credentials = getCredentials(authType, userName, password,serviceStringForProfile )

        val finalURL = NetworkConfiguration.getInstance().generateURLForAuthenticationAPICall(credentials, NetworkConfiguration.NetworkTypes.PEGA_NETWORK)
        val networkModel = NetworkModel.NetworkModelBuilder()
                .setNetworkUrl(finalURL)
                .setBaseCallback(loginCallback)
                .setMethod(CallType.GET)
                .setNetworkType(NetworkConfiguration.NetworkTypes.PEGA_NETWORK)
                .setNetworkInterface(NetworkConfiguration.getInstance().defaultNetworkInterface)
//                .setNetworkInterface(NetworkConfiguration.NetworkInterfaces.ANDROID_NETWORK_INTERFACE)
                .setKey(ApiConstant.AUTHENTICATE_KEY)
                //                .setRetryIfFail(false)
                .build()

        ApiRestCall(networkModel).addRequest()

    }






    fun requestCustomerProfile(networkBaseCallback: NetworkBaseCallback) {

        var mUserName = DataSingleton.getDataSingleton()
                .getSharedPreference().getStringValue(AppConstant.WebViewConstants.USER_NAME, "")!!
        val bodyParams = getBodyForCustomerProfile(mUserName)

        val headerParams = HashMap<String, String>()
        headerParams.put("Cookie", "JSESSIONID=" + NetworkConfiguration.getInstance().jsessionid)

        val queryParams = HashMap<String, String>()
        queryParams.put("application-id", NetworkConfiguration.APPILCATION_ID)
        queryParams.put("operation", "getBUPCustomerProfileRequest")

        val finalUrl = NetworkConfiguration.getInstance()
                .getMessageUrl(NetworkConfiguration.NetworkTypes.PEGA_NETWORK)

        val networkModel = NetworkModel.NetworkModelBuilder()
                .setBaseCallback(networkBaseCallback)
                .setNetworkUrl(finalUrl)
                .setMethod(CallType.POST)
                .setHeaders(headerParams)
                .setQueryParameters(queryParams)
                .setBody(bodyParams)
                .setNetworkType(NetworkConfiguration.NetworkTypes.PEGA_NETWORK)
                .setNetworkInterface(NetworkConfiguration.getInstance().defaultNetworkInterface)
                .setKey(ApiConstant.BUP_CUSTOMER_PROFILE)
                .build()
        ApiRestCall(networkModel).addRequest()
    }


   private fun getBodyForCustomerProfile(userName: String): JsonObject {
        val jsonObject = JsonObject()
        val requestHeader = JsonObject()
        val request = JsonObject()
        requestHeader.addProperty("sessionId", NetworkConfiguration.getInstance().sessionID)
        requestHeader.addProperty("language",DataSingleton.getDataSingleton().language)
        requestHeader.addProperty("organizationID", DataSingleton.getDataSingleton().applicationName)
        jsonObject.add("requestHeader", requestHeader)
        request.addProperty("user", userName)
        request.addProperty("username", userName)
        request.addProperty("password", "")
        request.addProperty("profileSaveTime", "")
        request.addProperty("AccountNumbers", "")
        jsonObject.add("request", request)
        return jsonObject
    }






    @SuppressLint("NewApi")
/* Method to get the credentials in Base64 encoding*/
    private  fun getCredentials(authType: String, username: String, password: String, serviceStringForProfile: Any?): String {
        val org = "BELL"

        var credentials: String
        val delimiter = "%#@%#@"
        val pwd = "pwd@" + password + delimiter + serviceStringForProfile
        val userId = username + "_" + Math.random()
        val usr_name = "device@" + userId + delimiter + "org@" + org + delimiter + "aT@" + authType + delimiter + "un@" + username + delimiter + "lang@en" + delimiter + "OS@NA"
        credentials = usr_name + ":" + pwd
        val encoded = Base64.encodeToString(credentials.toByteArray(), Base64.DEFAULT)
        android.util.Log.d("", "")
        try {
            credentials = URLEncoder.encode(encoded, "UTF-8")
                    .replace("\\+".toRegex(), "%20")
                    .replace("\\%21".toRegex(), "!")
                    .replace("\\%27".toRegex(), "'")
                    .replace("\\%28".toRegex(), "(")
                    .replace("\\%29".toRegex(), ")")
                    .replace("\\%0A".toRegex(), "")
                    .replace("\\%7E".toRegex(), "~")//%0A
            android.util.Log.d("", "")

        } catch (e: UnsupportedEncodingException) {
            AppLog.error(e.message!!)
        }

        return credentials
    }




}