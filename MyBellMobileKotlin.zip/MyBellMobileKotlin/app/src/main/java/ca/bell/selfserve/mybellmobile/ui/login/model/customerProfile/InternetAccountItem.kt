package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class InternetAccountItem(

        @field:SerializedName("backendResponseCode")
        val backendResponseCode: Any? = null,

        @field:SerializedName("contactTelephone")
        val contactTelephone: Any? = null,

        @field:SerializedName("contactName")
        val contactName: Any? = null,

        @field:SerializedName("language")
        val language: Any? = null,

        @field:SerializedName("accountNumber")
        val accountNumber: String? = null,

        @field:SerializedName("responseStatus")
        val responseStatus: String? = null,

        @field:SerializedName("accountStatusReason")
        val accountStatusReason: Any? = null,

        @field:SerializedName("responseCode")
        val responseCode: Any? = null,

        @field:SerializedName("accountStatus")
        val accountStatus: String? = null,

        @field:SerializedName("affiliateName")
        val affiliateName: Any? = null,

        @field:SerializedName("emailAddress")
        val emailAddress: Any? = null,

        @field:SerializedName("responseStatusDescription")
        val responseStatusDescription: Any? = null,

        @field:SerializedName("responseVersion")
        val responseVersion: Any? = null,

        @field:SerializedName("otherIdentifiers")
        val otherIdentifiers: OtherIdentifiers? = null,

        @field:SerializedName("accountStatusDate")
        val accountStatusDate: Any? = null,

        @field:SerializedName("nickname")
        val nickname: String? = null,

        @field:SerializedName("linkType")
        val linkType: Any? = null,

        @field:SerializedName("accountActivationDate")
        val accountActivationDate: Any? = null,

        @field:SerializedName("billingAddress")
        val billingAddress: Any? = null
)