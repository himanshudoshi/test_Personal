package ca.bell.selfserve.data.network.model


interface NetworkBaseCallback  {

    fun onSuccessfulResponse(response: Any?,headers: Map<String, ArrayList<String>>)

    fun onFailure(response: Any?)
}
