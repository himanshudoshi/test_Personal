package ca.bell.selfserve.mybellmobile.sharedpreferences

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.text.TextUtils

class SharedPreferenceManager private constructor(protected var mContext: Context) {

    private val mSharedPreferences: SharedPreferences
    private val mSharedPreferencesEditor: SharedPreferences.Editor

    init {
        mSharedPreferences = mContext.getSharedPreferences(PreferencesConstant.PREFERENCES_NAME, Context.MODE_PRIVATE)
        mSharedPreferencesEditor = mSharedPreferences.edit()
    }


    @SuppressLint("NewApi")
    fun setValue(key: String, value: Any) {

        when(value) {
            is String -> mSharedPreferencesEditor.putString(key, value)
            is Int ->  mSharedPreferencesEditor.putInt(key, value)
            is Double -> mSharedPreferencesEditor.putString(key,  java.lang.Double.toString(value))
            is Long -> mSharedPreferencesEditor.putLong(key, value)
            is Boolean -> mSharedPreferencesEditor.putBoolean(key, value)
        }

        mSharedPreferencesEditor.apply()

    }

    /**
     * Retrieves String value from preference
     *
     * @param key          key of preference
     * @param defaultValue default value if no key found
     */
    fun getStringValue(key: String): String? {
        return mSharedPreferences.getString(key, null)
    }

    /**
     * Retrieves String value from preference
     *
     * @param key          key of preference
     * @param defaultValue default value if no key found
     */
    fun getStringValue(key: String, defaultValue: String): String? {
        return mSharedPreferences.getString(key, null)
    }

    /**
     * Retrieves int value from preference
     *
     * @param key          key of preference
     * @param defaultValue default value if no key found
     */
    fun getIntValue(key: String): Int {
        return mSharedPreferences.getInt(key, 0)
    }

    /**
     * Retrieves long value from preference
     *
     * @param key          key of preference
     * @param defaultValue default value if no key found
     */
    fun getLongValue(key: String): Long {
        return mSharedPreferences.getLong(key, 0L)
    }

    /**
     * Retrieves boolean value from preference
     *
     * @param keyFlag      key of preference
     * @param defaultValue default value if no key found
     */
    fun getBooleanValue(keyFlag: String): Boolean {
        return mSharedPreferences.getBoolean(keyFlag, false)
    }

    /**
     * Removes key from preference
     *
     * @param key key of preference that is to be deleted
     */
    fun removeKey(key: String) {
        if (mSharedPreferencesEditor != null) {
            mSharedPreferencesEditor.remove(key)
            mSharedPreferencesEditor.commit()
        }
    }

    /**
     * Clears all the preferences stored
     */
    fun clear() {
        mSharedPreferencesEditor.clear().commit()
    }

//    /**
//     * Stores String value in encrypted form in the shared preference
//     *
//     * @param key   key of preference
//     * @param value value for that key
//     */
//    fun setEncryptedValue(key: String, value: String) {
//        val encValue = Utility.encrypt(value)
//        if (!TextUtils.isEmpty(encValue))
//            this.setValue(key, encValue!!)
//        else {
//            AppLog.error("Encryption failed for value saving the non encrypted value in the prefrences $value")
//            this.setValue(key, value)
//        }
//    }
//
//    fun getDecryptedValue(key: String, defaultValue: String): String? {
//        val value = this.getStringValue(key, defaultValue)
//        if (!TextUtils.isEmpty(value)) {
//            // decrypt the values
//            val decryptedValue = Utility.decrypt(value!!)
//            if (!TextUtils.isEmpty(decryptedValue))
//                return decryptedValue
//            else {
//                AppLog.error("Decryption failed for value returing the encrypted value from the prefrences ")
//                return value
//            }
//        } else {
//            return value
//        }
//    }

    companion object {

        private var mSharedPreferenceUtils: SharedPreferenceManager? = null

        /**
         * Creates single mInstance of SharedPreferenceUtils
         * @param context context of Activity or Service
         * @return Returns mInstance of SharedPreferenceUtils
         */
        @Synchronized
        fun getInstance(context: Context): SharedPreferenceManager {

            if (mSharedPreferenceUtils == null) {
                mSharedPreferenceUtils = SharedPreferenceManager(context.applicationContext)
            }
            return mSharedPreferenceUtils as SharedPreferenceManager
        }
    }


    fun hasData(key: String): Boolean {
        val getDataForKey = getStringValue(key)
        return  (getDataForKey != null && !getDataForKey.isEmpty())
    }

}