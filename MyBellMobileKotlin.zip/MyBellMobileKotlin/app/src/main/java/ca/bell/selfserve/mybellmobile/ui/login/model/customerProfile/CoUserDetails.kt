package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class CoUserDetails(

        @field:SerializedName("hireDate")
        val hireDate: Any? = null,

        @field:SerializedName("occupation")
        val occupation: Any? = null,

        @field:SerializedName("homePhone")
        val homePhone: Any? = null,

        @field:SerializedName("name")
        val name: String? = null,

        @field:SerializedName("employer")
        val employer: Any? = null,

        @field:SerializedName("workPhone")
        val workPhone: Any? = null
)