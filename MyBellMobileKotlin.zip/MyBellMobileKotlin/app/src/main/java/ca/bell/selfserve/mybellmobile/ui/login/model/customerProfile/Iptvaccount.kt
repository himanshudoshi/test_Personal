package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
data class Iptvaccount (

    var internetAccountNumber: String?=null,
    var oneBillId: String? = null,
    var custProfileId: String? = null,
    var tvaccountNumber: String? = null,
    var typeOfccount: String? = null
)