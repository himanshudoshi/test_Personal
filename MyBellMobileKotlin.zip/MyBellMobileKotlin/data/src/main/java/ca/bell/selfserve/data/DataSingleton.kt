package ca.bell.selfserve.data

import android.app.Application
import android.content.Context
import ca.bell.selfserve.data.network.utility.NetworkManager

import ca.bell.selfserve.data.network.service.VolleyHelperImpl
import ca.bell.selfserve.mybellmobile.sharedpreferences.SharedPreferenceManager

/**
 * Created by GG00495581 on 1/11/2018.
 */
class DataSingleton {



    private val volleyHelper: VolleyHelperImpl
    private val context: Context


    var language = "";
    var applicationName: String=""

    val networkManager:NetworkManager ;

    private constructor(volleyHelper: VolleyHelperImpl, context: Context) {
        this.volleyHelper = volleyHelper
        this.context = context
        networkManager = NetworkManager.getNetworkManager()

        // initialize shared preferences
        sharedPreference = SharedPreferenceManager.getInstance(context)

    }

    fun  getVolleyHelperImpl() : VolleyHelperImpl {
        return volleyHelper
    }


    fun getContext():Context{
        return context;
    }


    /**
     * method to return shared preferences object
     *
     * @return
     */
    private lateinit  var sharedPreference: SharedPreferenceManager

    fun getSharedPreference():SharedPreferenceManager{
        return sharedPreference
    }


    companion object {

        private var initialised = false
        private lateinit var instance: DataSingleton

        fun  getDataSingleton() : DataSingleton{
            return instance
        }

        fun init(application: Application) {
            if (application == null ||  initialised ) return
            initialised =true
            NetworkManager.init(application)
            instance = DataSingleton(VolleyHelperImpl(application),application)

        }
    }




}
