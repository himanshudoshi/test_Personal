package ca.bell.selfserve.data.network.model


object ApiConstant {

    /**
     * Supported request methods.
     */
    interface Method {

    }


    interface ErrorCodes {
        companion object {
            val CONNECTION_ISSUE = -505
        }
    }

//    companion object
//    {

        val GET_CONFIG_KEY:String = "GET_CONFIG"
        val AUTHENTICATE_KEY = "AUTHENTICATE"
        val GET_NSI_PROFILE_KEY = "GET_NSI_PROFILE"
        val GET_CMS = "GET_CMS"
        val GET_PAYMENT = "GET_PAYMENT_DATA"
        val BUP_CUSTOMER_PROFILE = "BUP_CUSTOMER_PROFILE"
        val ACCOUNT_DATA_STATUS = "ACCOUNT_DATA_STATUS"
        val SUBSCRIBER_IMAGE = "subscriber_image"
        val CREDENTIALS = "CREDENTIALS"
        val LANGUAGE = "LANGUAGE"
        val LOGOUT = "LOGOUT"
        val KEY_CONFIGURATION_RESPONSE = "CONFIGURATIONRESPONSE"
        val GET_CURRENT_PACKAGE = "GET_CURRENT_PACKAGE"
        val GET_SUMMARY = "GET_SUMMARY"
        val GET_PACKAGES = "GET_PACKAGES"
        val GET_FEATURE_DATA = "GET_FEATURE_DATA"
        val GET_REVIEW = "GET_REVIEW"
        val GET_ORDERS = "GET_ORDERS"
        val PRODUCT_FEATURE = "PRODUCT_FEATURE"
        val PREFETCH_OMF = "PREFETCH_OMF"
        val GET_SPEED_COMPARISON = "GET_SPEED_COMPARISON"
        val SELECT_PACKAGE = "SELECT_PACKAGE"
//    }

}
