/*
 * Copyright 2016, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ca.bell.selfserve.mybellmobile.common


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentTransaction


object ActivityUtils {

    /**
     * The `fragment` is added to the container view with id `frameId`. The operation is
     * performed by the `fragmentManager`.
     */
    fun addFragmentToActivity(fragmentManager: FragmentManager,
                              fragment: Fragment, frameId: Int, tag: String) {

        val transaction : FragmentTransaction = fragmentManager.beginTransaction()
        transaction.add(frameId, fragment, tag)
        transaction.commit()
    }

    /**
     * The `fragment` is replaced to the container view with id `frameId`. The operation is
     *
     * @param fragmentManager
     * @param fragment
     * @param frameId
     */
    fun replaceFragmentToActivity(fragmentManager: FragmentManager,
                                  fragment: Fragment, frameId: Int, tag: String) {

        val transaction : FragmentTransaction = fragmentManager.beginTransaction()
        transaction.replace(frameId, fragment, tag)
        transaction.commitAllowingStateLoss()
    }

    /**
     * The `fragment` is added to the container view with id `frameId`. The operation is
     * performed by the `fragmentManager`.
     *
     * @param fragmentManager
     * @param fragment
     * @param frameId
     * @param bundle
     */
    fun addFragmentWithBundle(fragmentManager: FragmentManager,
                              fragment: Fragment, frameId: Int, bundle: Bundle, tag: String) {

        val transaction : FragmentTransaction = fragmentManager.beginTransaction()
        fragment.arguments = bundle // fragment.setArguments(bundle)
        transaction.add(frameId, fragment, tag)
        transaction.commit()
    }

    /**
     * The `fragment` is replaced to the container view with id `frameId`. The operation is
     *
     * @param fragmentManager
     * @param fragment
     * @param frameId
     * @param bundle
     */
    fun replaceFragmentWithBundle(fragmentManager: FragmentManager,
                                  fragment: Fragment, frameId: Int, bundle: Bundle, tag: String) {

        val transaction: FragmentTransaction  = fragmentManager.beginTransaction()
        fragment.arguments = bundle
        transaction.replace(frameId, fragment, tag)
        transaction.commit()
    }

    /**
     * Method to remove fragment
     * @param fragmentManager
     * @param fragment
     */
    fun removeFragment(fragmentManager: FragmentManager,
                       fragment: Fragment) {

        val transaction : FragmentTransaction = fragmentManager.beginTransaction()
        transaction.remove(fragment)
        transaction.commit()
    }
}
