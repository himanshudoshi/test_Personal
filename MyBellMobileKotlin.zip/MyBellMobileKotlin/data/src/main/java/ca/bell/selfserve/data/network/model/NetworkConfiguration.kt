package ca.bell.selfserve.data.network.model


import ca.bell.selfserve.data.BuildConfig
import ca.bell.selfserve.data.network.model.NetworkConfiguration.ApiGatewayUrls.Companion.APIGATEWAY_NETWORK_DIT_URL
import ca.bell.selfserve.data.network.model.NetworkConfiguration.ApiGatewayUrls.Companion.APIGATEWAY_NETWORK_PRODUCTION_URL
import ca.bell.selfserve.data.network.model.NetworkConfiguration.ApiGatewayUrls.Companion.APIGATEWAY_NETWORK_SFT_URL
import ca.bell.selfserve.data.network.model.NetworkConfiguration.ApiGatewayUrls.Companion.APIGATEWAY_NETWORK_SOAK_URL

import ca.bell.selfserve.data.network.model.NetworkConfiguration.NetworkTypes.Companion.API_GATEWAY_NETWORK
import ca.bell.selfserve.data.network.model.NetworkConfiguration.NetworkTypes.Companion.PEGA_NETWORK
import ca.bell.selfserve.data.network.model.NetworkConfiguration.PegaUrls.Companion.NETWORK_DIT_URL
import ca.bell.selfserve.data.network.model.NetworkConfiguration.PegaUrls.Companion.NETWORK_PRODUCTION_URL
import ca.bell.selfserve.data.network.model.NetworkConfiguration.PegaUrls.Companion.NETWORK_SFT_URL
import ca.bell.selfserve.data.network.model.NetworkConfiguration.PegaUrls.Companion.NETWORK_SOAK_URL

public class NetworkConfiguration protected constructor() {

    /**
     * region Getter Setters for Network Configuration Valraibles
     * Network Configuration Variables
     */
    var deviceID: String =""
    var jsessionid: String=""
    var networkType: String=""
    var sessionID: String=""
    var environmentType: String=""
    var applicationID: String=""
    var smSessionToken: String=""
    var scheme: String=""

    /**
     * method to return configuration api url
     *
     * @return
     */
    //TODO: Here we will change the logic to fetch the URL based on app domain and app type.
    //String URL = "https://mbm-dit2app.bell.ca/mobileapp/conf/appStore/MBM_Config.json";
    //String URL = "https://mbm-dit1app.bell.ca/mobileapp/conf/appStore/UI_ForceUpgrade_BellConfig.json";
    val configurationURL: String
        get() {
            val domain = ""
            val appType = ""
            return "https://mbm-dit2app.bell.ca/mobileapp/conf/appStore/"
        }
    //endregion


    val defaultNetworkInterface: String
        get() = NetworkInterfaces.VOLLEY_NETWORK_INTERFACE


    /**
     * method returns NSI authentication url
     *
     * @return
     */
    //TODO: Here we will change the logic to fetch the URL based on app domain and app type.
    val nsiUrl: String
        get() {
            val domain = ""
            val appType = ""
            return "http://nsi.bwanet.ca:8180/subid;appId=MBMSelfServe"
        }

    /*NSI NON PROD Urls*/
    interface NonProductionUrls {
        companion object {
            val BELL_NSI_NON_PROD_URL = "http://10.240.8.175:8180/subid;appId=MBMSelfServe"
            val VIRGIN_NSI_NON_PROD_URL = "http://10.240.8.175:8180/subid;appId=MVMSelfServe"
        }
    }

    /*NSI prod URL's*/
    interface ProductionUrls {
        companion object {
            val BELL_NSI_PROD_URL = "http://nsi.bwanet.ca:8180/subid;appId=MBMSelfServe"
            val VIRGIN_NSI_PROD_URL = "http://nsi.bwanet.ca:8180/subid;appId=MVMSelfServe"
        }
    }

    //PEGA URLS CONSTANTS
    interface PegaUrls {
        companion object {
            val NETWORK_DIT_URL = "https://mbm-dit1app.bell.ca/HttpCapService"
            val NETWORK_SFT_URL = "https://mbm-sft1app.bell.ca/mobile/HttpCapService"
            val NETWORK_SOAK_URL = "https://pre-mybell.bell.ca/mobile/HttpCapService"
            val NETWORK_PRODUCTION_URL = "https://mybell.bell.ca/mobile/HttpCapService"
        }
    }

    //ENVIRONMENT TYPES
    interface environmentNames {
        companion object {
            val DIT = "DIT"
            val SFT = "SFT"
            val SOAK = "SOAK"
            val PROD = "PROD"
        }
    }


    //API GATEWAY URLS
    interface ApiGatewayUrls {
        companion object {
            val APIGATEWAY_NETWORK_DIT_URL = "https://mbm-dit1app.bell.ca/mobile/HttpCapService"
            val APIGATEWAY_NETWORK_SFT_URL = "https://mbm-sft1app.bell.ca/mobile/HttpCapService"
            val APIGATEWAY_NETWORK_SOAK_URL = "https://pre-mybell.bell.ca/mobile/HttpCapService"
            val APIGATEWAY_NETWORK_PRODUCTION_URL = "https://mybell.bell.ca/mobile/HttpCapService"
            val APIGATEWAY_NETWORK_DIT_URL1 = "https://apigate.bell.ca/channelbellcaext/UXP.Services"
        }
        //    https://apigate.bell.ca/channelbellcaext/UXP.Services/ecare/Profile/Mobility/AccountDataStatus
    }


    //NETWORK TYPES
    interface NetworkTypes {
        companion object {
            val API_GATEWAY_NETWORK = "APIGATEWAY"
            val PEGA_NETWORK = "PEGANETWORK"
        }
    }

    //NETWORK INTERFACES
    interface NetworkInterfaces {
        companion object {
//            val RETROFIT_NETWORK_INTERFACE = "RETROFIT"
            val ANDROID_NETWORK_INTERFACE = "ANDROID"
            val VOLLEY_NETWORK_INTERFACE = "VOLLEY"
        }
    }

    /**
     * API to get the Doamin Specific URL used to call the Web Services
     *
     * @param networkType : PEGA or API Gateway
     * @return networkUrl : Domain URL for API call
     */
    fun getNetworkUrl(networkType: String): String? {


        var networkURL: String? = null

        when (networkType) {
            API_GATEWAY_NETWORK -> networkURL = APIGATEWAY_NETWORK_DIT_URL

//                when (BuildConfig.FLAVOR_servertype.replace("_".toRegex(), "")) {
//                environmentNames.DIT -> networkURL = APIGATEWAY_NETWORK_DIT_URL
//                environmentNames.PROD -> networkURL = APIGATEWAY_NETWORK_PRODUCTION_URL
//                environmentNames.SFT -> networkURL = APIGATEWAY_NETWORK_SFT_URL
//                environmentNames.SOAK -> networkURL = APIGATEWAY_NETWORK_SOAK_URL
//            }
            PEGA_NETWORK -> networkURL = NETWORK_DIT_URL
//                when (BuildConfig.FLAVOR_servertype.replace("_".toRegex(), "")) {
//                environmentNames.DIT -> networkURL = NETWORK_DIT_URL
//                environmentNames.PROD -> networkURL = NETWORK_PRODUCTION_URL
//                environmentNames.SFT -> networkURL = NETWORK_SFT_URL
//                environmentNames.SOAK -> networkURL = NETWORK_SOAK_URL
//            }
        }

        return networkURL
    }

    fun generateURLForAuthenticationAPICall(credentials: String, networkType: String): String {
        var finalURL: String? = null
        val apiName = "login"
        val scheme = SCHEME
        val applicationID = APPILCATION_ID
        val baseURL = getInstance().getNetworkUrl(networkType)
        finalURL = "$baseURL/$apiName?scheme=$scheme&application-id=$applicationID&credentials=$credentials"
        return finalURL
    }

    fun generateURLForAPICalls(APIName: String, networkType: String): String {
        val baseURL = getInstance().getNetworkUrl(networkType)
//String finalURL = baseURL + "/messaging?" + "application-id=" + NetworkConfiguration.APPILCATION_ID + "&" + "operation=" + APIName;
        return baseURL!! + "/"
    }


    fun getBaseUrl(networkType: String): String? {
        return getInstance().getNetworkUrl(networkType)
    }


    fun getMessageUrl(networkType: String): String {
        val baseURL = getInstance().getNetworkUrl(networkType)
        return baseURL!! + "/messaging"
    }


    //    public String generateURLForAPICalls_universal(String APIName, String networkType) {
    //        String baseURL = NetworkConfiguration.getInstance().getNetworkUrl(networkType);
    ////        String finalURL = baseURL+"/";
    ////        String finalURL = baseURL + "/messaging?" + "application-id=" + NetworkConfiguration.APPILCATION_ID + "&" + "operation=" + APIName;
    ////        String finalURL = baseURL + "/messaging?" + "application-id=" + NetworkConfiguration.APPILCATION_ID + "&" + "operation=" + APIName;
    //        //        String finalURL = baseURL + "/messaging?" + "application-id=" + NetworkConfiguration.APPILCATION_ID + "&" + "operation=" + APIName;
    ////        https://mbm-dit1app.bell.ca/HttpCapService/messaging?application-id=ca.bell.selfserve.mybellmobile.web&operation=getBUPCustomerProfileRequest
    ////        https://mbm-dit1app.bell.ca/HttpCapService/messaging?application-id=ca.bell.selfserve.mybellmobile.web&operation=getBUPCustomerProfileRequest
    //        String finalURL = baseURL + "/messaging" ;
    //        return finalURL;
    //    }


    //endregion

    fun generateURLForAPICalls_(APIName: String, networkType: String): String {
        val baseURL = getInstance().getNetworkUrl(networkType)
//String finalURL = baseURL + "/messaging?" + "application-id=" + NetworkConfiguration.APPILCATION_ID + "&" + "operation=" + APIName;
        return "$baseURL/$APIName"
    }

    companion object {


        //For JSESSION ID Cookie
        val SET_COOKIE_KEY = "Set-Cookie"
        val COOKIE_KEY = "Cookie"
        val SESSION_COOKIE = "JSESSIONID"
        val AUTH_CODE = "Chroma-Auth-Error-Code"

        //Final constants for Network Configuration
        val APPILCATION_ID = "ca.bell.selfserve.mybellmobile.web"
        val SCHEME = "URLBasic"

        //endregion

        //TODO: This url will be changed based on the environment of the app.
        var webAppURL = "https://mbm-dit1app.bell.ca/hosting/ca.bell.selfserve.mybellmobile.web.nativepoc/LATEST/indexHTTP.html"
        //public static String webAppURL = "http://www.bell.ca/";

        //region Single Instance Implementation for Network Configuration Class
        private var _instance: NetworkConfiguration? = null


        @Synchronized
        fun getInstance(): NetworkConfiguration {

            if (_instance == null) {
                _instance = NetworkConfiguration()
            }

            return _instance as NetworkConfiguration
        }
    }

}
