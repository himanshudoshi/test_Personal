package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class OneBillAccountItem(

        @field:SerializedName("currentBillingMedium")
        val currentBillingMedium: CurrentBillingMedium? = null,

        @field:SerializedName("backendResponseCode")
        val backendResponseCode: Any? = null,

        @field:SerializedName("lastUpdateStamp")
        val lastUpdateStamp: Int? = null,

        @field:SerializedName("ottaccounts")
        val ottaccounts: Any? = null,

        @field:SerializedName("accountSubType")
        val accountSubType: AccountSubType? = null,

        @field:SerializedName("lastUpdateDate")
        val lastUpdateDate: Long? = null,

        @field:SerializedName("language")
        val language: Language? = null,

        @field:SerializedName("mobilityAccounts")
        val mobilityAccounts: MobilityAccounts? = null,

        @field:SerializedName("isDelinquent")
        val isDelinquent: Boolean? = null,

        @field:SerializedName("accountStatusReason")
        val accountStatusReason: String? = null,

        @field:SerializedName("responseCode")
        val responseCode: Any? = null,

        @field:SerializedName("accountStatus")
        val accountStatus: String? = null,

        @field:SerializedName("emailAddress")
        val emailAddress: String? = null,

        @field:SerializedName("responseStatusDescription")
        val responseStatusDescription: String? = null,

        @field:SerializedName("responseVersion")
        val responseVersion: String? = null,

        @field:SerializedName("identification")
        val identification: Any? = null,

        @field:SerializedName("accountGLProvinceCode")
        val accountGLProvinceCode: String? = null,

        @field:SerializedName("iptvaccounts")
        val iptvaccounts: Any? = null,

        @field:SerializedName("accountBalanceDetails")
        val accountBalanceDetails: AccountBalanceDetails? = null,

        @field:SerializedName("nickname")
        val nickname: String? = null,

        @field:SerializedName("tvaccounts")
        val tvaccounts: Tvaccounts? = null,

        @field:SerializedName("erouteIndicator")
        val erouteIndicator: Boolean? = null,

        @field:SerializedName("billSequenceNo")
        val billSequenceNo: Int? = null,

        @field:SerializedName("coUserDetails")
        val coUserDetails: CoUserDetails? = null,

        @field:SerializedName("creditClass")
        val creditClass: CreditClass? = null,

        @field:SerializedName("contactTelephone")
        val contactTelephone: ContactTelephone? = null,

        @field:SerializedName("contactName")
        val contactName: ContactName? = null,

        @field:SerializedName("internetAccounts")
        val internetAccounts: InternetAccounts? = null,

        @field:SerializedName("accountType")
        val accountType: AccountType? = null,

        @field:SerializedName("accountNumber")
        val accountNumber: String? = null,

        @field:SerializedName("responseStatus")
        val responseStatus: String? = null,

        @field:SerializedName("affiliateName")
        val affiliateName: Any? = null,

        @field:SerializedName("otherIdentifiers")
        val otherIdentifiers: Any? = null,

        @field:SerializedName("collectionStatus")
        val collectionStatus: String? = null,

        @field:SerializedName("billingMediaTypeDetails")
        val billingMediaTypeDetails: List<BillingMediaTypeDetailsItem?>? = null,

        @field:SerializedName("arbalance")
        val arbalance: Arbalance? = null,

        @field:SerializedName("accountStatusDate")
        val accountStatusDate: Long? = null,

        @field:SerializedName("accountStatusCode")
        val accountStatusCode: AccountStatusCode? = null,

        @field:SerializedName("wirelineAccounts")
        val wirelineAccounts: WirelineAccounts? = null,

        @field:SerializedName("linkType")
        val linkType: Any? = null,

        @field:SerializedName("accountActivationDate")
        val accountActivationDate: Long? = null,

        @field:SerializedName("billingAddress")
        val billingAddress: BillingAddress? = null,

        @field:SerializedName("billCycleCode")
        val billCycleCode: Int? = null,

        @field:SerializedName("billDueDate")
        val billDueDate: Long? = null,

        @field:SerializedName("paymentInfo")
        val paymentInfo: PaymentInfo? = null
)