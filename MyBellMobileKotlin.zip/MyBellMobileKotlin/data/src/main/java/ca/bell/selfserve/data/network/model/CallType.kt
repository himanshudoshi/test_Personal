package ca.bell.selfserve.data.network.model

/**
 * Created by GG00539076 on 5/23/2018.
 */
class CallType {
    companion object {
        val DEPRECATED_GET_OR_POST = -1
        val GET = 0
        val POST = 1
        val PUT = 2
        val DELETE = 3
        val HEAD = 4
        val OPTIONS = 5
        val TRACE = 6
        val PATCH = 7
    }
}