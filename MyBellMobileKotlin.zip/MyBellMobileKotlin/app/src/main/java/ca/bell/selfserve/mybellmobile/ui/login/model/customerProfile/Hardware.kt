package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class Hardware(

        @field:SerializedName("esn")
        val esn: Any? = null,

        @field:SerializedName("sequenceNumber")
        val sequenceNumber: Double? = null,

        @field:SerializedName("esnoriginal")
        val esnoriginal: Any? = null,

        @field:SerializedName("imeioriginal")
        val imeioriginal: Any? = null,

        @field:SerializedName("imeiequipmentType")
        val imeiequipmentType: Any? = null,

        @field:SerializedName("esnequipmentType")
        val esnequipmentType: Any? = null,

        @field:SerializedName("imei")
        val imei: Any? = null,

        @field:SerializedName("simnumber")
        val simnumber: String? = null,

        @field:SerializedName("modelNumber")
        val modelNumber: Any? = null,

        @field:SerializedName("simsequenceNumber")
        val simsequenceNumber: Double? = null,

        @field:SerializedName("simequipmentType")
        val simequipmentType: SimequipmentType? = null,

        @field:SerializedName("deviceImageNickname")
        val deviceImageNickname: Any? = null
)