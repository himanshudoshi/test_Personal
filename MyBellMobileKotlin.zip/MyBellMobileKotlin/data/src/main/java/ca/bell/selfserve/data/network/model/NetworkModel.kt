package ca.bell.selfserve.data.network.model


import com.google.gson.JsonObject

import java.util.HashMap

/**
 * Created by gg00539076 on 4/25/2018.
 */


class NetworkModel {


    private lateinit var ibaseCallbackNetwork: NetworkBaseCallback
    private  var networkType: String? = null//pega or apigate
    private lateinit var networkURL: String
    private lateinit var key: String
    private var method: Int = 0
    private var bodyParameters: JsonObject?=null
    private var networkInterface: String?=null//volley retro
    private var headerParams: HashMap<String, String> = HashMap()
    private var queryParams: HashMap<String, String> = HashMap()
    private var jSessionID: String?=null
    private var isRetryIfFail = true
    private var extraObject: Map<String, Any> = HashMap()
    private var tag: Any?= null
    private var priority: Priority = Priority.NORMAL


    fun getIbaseCallbackNetwork() = ibaseCallbackNetwork
    fun getNetworkType() = networkType
    fun getNetworkURL() = networkURL
    fun getKey() = key
    fun getMethod() = method
    fun getBodyParameters() = bodyParameters
    fun getNetworkInterface() = networkInterface
    fun getHeaderParams() = headerParams
    fun getQueryParams() = queryParams
    fun getJSessionID() = jSessionID
    fun IsRetryIfFail() = isRetryIfFail
    fun getExtraObject() = extraObject
    fun getTag() = tag
    fun getPriority() = priority


    private constructor()
    private constructor(builder: NetworkModel) {
        this.ibaseCallbackNetwork = builder.ibaseCallbackNetwork
        this.networkType = builder.networkType
        this.networkURL = builder.networkURL
        this.key = builder.key
        this.method = builder.method
        this.bodyParameters = builder.bodyParameters
        this.networkInterface = builder.networkInterface
        this.headerParams = builder.headerParams
        this.queryParams = builder.queryParams
        this.jSessionID = builder.jSessionID
        this.isRetryIfFail = builder.isRetryIfFail
        this.extraObject = builder.extraObject
        this.priority = builder.priority
        this.tag = builder.tag
    }


    fun getjSessionID(): String? {
        return jSessionID
    }


    //Builder Class
    class NetworkModelBuilder {
        private val networkModel: NetworkModel

        init {
            networkModel = NetworkModel()
        }


        fun setRetryIfFail(retryIfFail: Boolean): NetworkModelBuilder {
            networkModel.isRetryIfFail = retryIfFail
            return this
        }

        fun setExtraObject(extraObject: Map<String, Any>): NetworkModelBuilder {
            networkModel.extraObject = extraObject
            return this
        }


        fun setBaseCallback(networkBaseCallback: NetworkBaseCallback): NetworkModelBuilder {
            networkModel.ibaseCallbackNetwork = networkBaseCallback
            return this
        }

        fun setNetworkType(networkType: String): NetworkModelBuilder {
            networkModel.networkType = networkType
            return this
        }

        fun setNetworkUrl(networkURL: String): NetworkModelBuilder {
            networkModel.networkURL = networkURL
            return this
        }

        fun setKey(key: String): NetworkModelBuilder {
            networkModel.key = key
            return this
        }

        fun setMethod(method: Int): NetworkModelBuilder {
            networkModel.method = method
            return this
        }

        fun setBody(bodyParameters: JsonObject): NetworkModelBuilder {
            networkModel.bodyParameters = bodyParameters
            return this
        }

        fun setNetworkInterface(networkInterface: String): NetworkModelBuilder {
            networkModel.networkInterface = networkInterface
            return this
        }


        fun setHeaders(headerParams: HashMap<String, String>): NetworkModelBuilder {
            networkModel.headerParams = headerParams
            return this
        }

        fun setQueryParameters(queryParams: HashMap<String, String>): NetworkModelBuilder {
            networkModel.queryParams = queryParams
            return this
        }

        fun setJsessionId(jSessionID: String): NetworkModelBuilder {
            networkModel.jSessionID = jSessionID
            return this
        }

        fun setTag(tag: Any): NetworkModelBuilder {
            networkModel.tag = tag
            return this
        }

        fun setPriority(priority: Priority): NetworkModelBuilder {
            networkModel.priority = priority
            return this
        }


        fun build(): NetworkModel {
            return NetworkModel(networkModel)
        }

    }
}
