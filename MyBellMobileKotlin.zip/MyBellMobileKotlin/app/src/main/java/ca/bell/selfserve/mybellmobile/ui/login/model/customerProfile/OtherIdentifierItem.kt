package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class OtherIdentifierItem(

        @field:SerializedName("identifier")
        val identifier: String? = null,

        @field:SerializedName("type")
        val type: String? = null
)