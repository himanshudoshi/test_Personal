package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName
data class ContactTelephone(

        @field:SerializedName("number")
        val number: String? = null,

        @field:SerializedName("extension")
        val extension: Any? = null
)