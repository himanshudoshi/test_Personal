package ca.bell.selfserve.mybellmobile.ui.login.service

import ca.bell.selfserve.data.DataSingleton
import ca.bell.selfserve.data.network.api.LoginAPI
import ca.bell.selfserve.data.network.model.ApiConstant
import ca.bell.selfserve.data.network.model.NetworkBaseCallback
import ca.bell.selfserve.data.network.model.NetworkConfiguration
import ca.bell.selfserve.mybellmobile.BellApp
import ca.bell.selfserve.utility.AppConstant
import ca.bell.selfserve.utility.AppLog
import ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile.CustomerProfileResponse
import com.google.gson.Gson
import com.google.gson.JsonObject
import org.json.JSONException
import org.json.JSONObject
import java.util.*
import kotlin.collections.ArrayList

/**
 * Created by AU00538779 on 5/4/2018.
 */

class LoginInteractor
(private val mLoginInteractorCallback:
 LoginInteractorCallback)
{

    val loginApi : LoginAPI = LoginAPI()


    fun authenticateUser(userName: String, password: String) {
        loginApi.performLogin(AppConstant.userType.BUP, userName, password, serviceStringForProfile ,getLoginCallback() )
    }

    private fun getLoginCallback(): NetworkBaseCallback {
        return object : NetworkBaseCallback{

            override fun onSuccessfulResponse(parsedObject: Any?,headers: Map<String, ArrayList<String>>) {
                /*Save and parse authentication response.*/
                if (headers.size >0 ) {
                    AppLog.info("authentication success when data is not null")
                    parseAndSetJSessionId(headers)
                    setSessionID()
                    mLoginInteractorCallback.onAuthenticationSuccess(headers)
                } else {
                    AppLog.info("authentication success but data is null")
                    mLoginInteractorCallback.onAuthenticationFailure(headers)
                }
            }

            override fun onFailure(response: Any?) {
                AppLog.info("authentication failure")
                if(response != null)
                    mLoginInteractorCallback.onAuthenticationFailure(response)
            }
        }
    }





    private val serviceStringForProfile: String
        get() {
            AppLog.debug("getServiceStringForProfile function called.")
            val maxAccounts = 5
            var serviceStringToEmbed = "actNums:{}"
            val customerProfile = DataSingleton.getDataSingleton().getSharedPreference().getStringValue(ApiConstant.BUP_CUSTOMER_PROFILE)


            if (customerProfile == null || customerProfile == "") {
                AppLog.debug("getServiceStringForProfile serviceStringToEmbed is " + serviceStringToEmbed)
                return serviceStringToEmbed
            } else {
                try {
                    var anyAccountErrorStatus = false
                    val dataList = ArrayList<String>()
                    val gson = Gson()
                    val (data) = gson.fromJson(customerProfile, CustomerProfileResponse::class.java)
                    val serviceData = data!!.customerProfile
                    if (serviceData!= null && serviceData.legacyAccounts!= null && serviceData.legacyAccounts.mobilityAccounts!= null) {
                        val mobilityAccount = serviceData.legacyAccounts.mobilityAccounts!!.mobilityAccount

                        for (i in mobilityAccount!!.indices) {
                            val account = mobilityAccount[i]
                            if (account!=null && account.lastUpdateDate!= null && !account.lastUpdateDate.equals("")) {
                                dataList.add(createBanString("Legacy", account.accountNumber!!, account.lastUpdateDate))
                            } else {
                                anyAccountErrorStatus = true
                            }
                        }
                    }
                    if (serviceData!= null && serviceData.oneBillAccounts!= null && serviceData.oneBillAccounts.oneBillAccount!= null) {
                        val oneBillAccount = serviceData.oneBillAccounts.oneBillAccount
                        for (i in oneBillAccount.indices) {
                            val account = oneBillAccount[i]
                            if (account!=null && account.lastUpdateDate!= null && !account.lastUpdateDate.equals("")) {
                                dataList.add(createBanString("OB", account.accountNumber!!, account.lastUpdateDate))
                            } else {
                                anyAccountErrorStatus = true
                            }

                            if (!anyAccountErrorStatus && account!=null && account.mobilityAccounts != null) {
                                val mobilityData = account.mobilityAccounts.mobilityAccount
                                for (z in mobilityData!!.indices) {
                                    val accountM = mobilityData.get(z)
                                    if (account!=null && account.lastUpdateDate != null && !account.lastUpdateDate.equals("")) {
                                        dataList.add(createBanString("Legacy", account.accountNumber!!, accountM?.lastUpdateDate))
                                    } else {
                                        anyAccountErrorStatus = true
                                    }
                                }
                            }
                        }
                    }
                    if (dataList.size > 0 && !anyAccountErrorStatus && maxAccounts >= dataList.size) {
                        serviceStringToEmbed = "actNums:"
                        for (i in dataList.indices) {
                            serviceStringToEmbed += dataList[i]
                            if (i != dataList.size - 1) {
                                serviceStringToEmbed += "##@@##"
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

            }
            AppLog.debug("getServiceStringForProfile serviceStringToEmbed is " + serviceStringToEmbed)
            return serviceStringToEmbed
        }



    private fun createBanString(actType: String, ban: String, pst: Long?): String {
        val jsonObject = JsonObject()
        jsonObject.addProperty("actType", actType)
        jsonObject.addProperty("ban", ban)
        jsonObject.addProperty("pst", pst)
        return jsonObject.toString()
    }



    private fun getBupCustomerCallback(): NetworkBaseCallback {
        return object : NetworkBaseCallback{

            /**
             * check whether customer profile data available in database
             * if available in database - fetch from database
             * else - call network api
             */
            override fun onSuccessfulResponse(data: Any?, headers: Map<String, ArrayList<String>>) {
                AppLog.info("requestCustomerProfileData success")

                val isDataNull = data == null
                var isResponsePresent = false

                val response = data.toString()

                if (!isDataNull) {
                    isResponsePresent = isSuccess(response)
                }

                if (isResponsePresent) {
                    val customerProfileResponse = Gson().fromJson(response, CustomerProfileResponse::class.java)
                    NetworkConfiguration.getInstance().smSessionToken = customerProfileResponse?.data?.sessionToken!!

                    BellApp.getInstance().getSharedPreference().setValue(ApiConstant.BUP_CUSTOMER_PROFILE, response);

                    //ToDo: app webview work
                    //BellApp.getInstance().getAppWebView().loadUrl(SendEventClass.sendEvent(AppConstant.WebViewConstants.BUP_USER))
                    mLoginInteractorCallback.onBUPCustomerProfileSuccess(customerProfileResponse as CustomerProfileResponse)

                } else {
                    mLoginInteractorCallback.onBUPCustomerProfileFailure(response)
                }
            }

            private fun isSuccess(response: String?): Boolean {
                val jsonObject: JSONObject
                try {
                    jsonObject = JSONObject(response)
                    val responseHeader = jsonObject.getJSONObject("responseHeader").getString("status")
                    return responseHeader != "failure"
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
                return false
            }

            override fun onFailure(response: Any?) {
                AppLog.info("requestCustomerProfileData failure")
                if(response != null)
                    mLoginInteractorCallback.onBUPCustomerProfileFailure(response)
            }




        }
    }


    fun requestCustomerProfileData() {
        loginApi.requestCustomerProfile(getBupCustomerCallback());
    }



    private fun parseAndSetJSessionId(headers: Map<String, List<String>>) {
        if (headers.containsKey(NetworkConfiguration.SET_COOKIE_KEY)) {
            for ((key, value) in headers) {
                if (key != null && key == NetworkConfiguration.SET_COOKIE_KEY) {
                    for (i in value.indices) {
                        val idValue = value[i]
                        if (idValue.contains("JSESSIONID")) {
                            val jsessionId = idValue.split("=".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                            val jSession = jsessionId[1].split(";".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                            NetworkConfiguration.getInstance().jsessionid=jSession[0]
                        } else if (idValue.contains("DEVICEID")) {
                            val deviceId = idValue.split("=".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                            val devId = deviceId[1].split(";".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                            NetworkConfiguration.getInstance().deviceID=devId[0]
                        }
                    }
                    break
                }
            }
        }
        if (NetworkConfiguration.getInstance().jsessionid != null) {
            //ToDo: app webview work
            //BellApp.getInstance().getAppWebView().setJsessionId()
        }
    }

    private fun setSessionID() {
        val sessionId: String
        val d = Date()
        val ranNum: String
        val rnd = Math.random()
        ranNum = rnd.toString().substring(2, 2)
        val timestamp = d.time
        sessionId = timestamp.toString() + "" + ranNum
        NetworkConfiguration.getInstance().sessionID=sessionId
    }



    interface LoginInteractorCallback {
        fun onBUPCustomerProfileSuccess(customerProfileResponse: CustomerProfileResponse)

        fun onBUPCustomerProfileFailure(data: Any)

        fun onAuthenticationSuccess(data: Any)

        fun onAuthenticationFailure(data: Any)
    }
}
