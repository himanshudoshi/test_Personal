package ca.bell.selfserve.mybellmobile.exception

import android.content.Context
import android.content.Intent
import android.os.Bundle
import ca.bell.selfserve.mybellmobile.ExceptionActivity


object ExceptionUtils {

    fun exitSystem() {
        android.os.Process.killProcess(android.os.Process.myPid())

        System.exit(0)
    }

    fun openExceptionActivity(context: Context, bundle: Bundle) {
        val intent = Intent(context, ExceptionActivity::class.java)
        intent.putExtras(bundle)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT)
        context.startActivity(intent)
    }

}
