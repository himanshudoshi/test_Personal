package ravipatel.com.encrydecrypoc

import android.util.Base64
import java.io.IOException
import java.security.*
import javax.crypto.BadPaddingException
import javax.crypto.Cipher
import javax.crypto.IllegalBlockSizeException
import javax.crypto.NoSuchPaddingException
import javax.crypto.spec.GCMParameterSpec

object AESManager {

    private val TRANSFORMATION_AES = "AES/GCM/NoPadding"
    private val ANDROID_KEY_STORE = "AndroidKeyStore"



    @Throws(UnrecoverableEntryException::class, NoSuchAlgorithmException::class, KeyStoreException::class, NoSuchProviderException::class, NoSuchPaddingException::class, InvalidKeyException::class, IOException::class, InvalidAlgorithmParameterException::class, SignatureException::class, BadPaddingException::class, IllegalBlockSizeException::class)
    fun encrypt(textToEncrypt: String, key: Key): String {

        val cipher = Cipher.getInstance(TRANSFORMATION_AES)
        //final GCMParameterSpec spec = new GCMParameterSpec(128, generateIV().getIV());
        cipher.init(Cipher.ENCRYPT_MODE, key)

        val iv = cipher.iv


        val encryptedByteValue = cipher.doFinal(textToEncrypt.toByteArray(charset("utf-8")))
        val encryptedValue64 = Base64.encodeToString(encryptedByteValue, Base64.NO_PADDING)


        return encryptedValue64 + "::" + convertByteArrayToString(iv)
    }




    fun convertByteArrayToString(data: ByteArray): String {
        //for (byte b: data) System.out.println(b);
        // put data into this char array
        val cbuf = CharArray(data.size)
        for (i in data.indices) {
            cbuf[i] = data[i].toChar()
        }

        return String(cbuf)
    }

    @Throws(UnrecoverableEntryException::class, NoSuchAlgorithmException::class, KeyStoreException::class, NoSuchProviderException::class, NoSuchPaddingException::class, InvalidKeyException::class, IOException::class, BadPaddingException::class, IllegalBlockSizeException::class, InvalidAlgorithmParameterException::class)
    fun decrypt(encryptedData: String, key: Key): String {

        val data = encryptedData.split("::".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()


        val cipher = Cipher.getInstance(TRANSFORMATION_AES)

        //String []data = readDataFromFile(encryptedData,filename);

        val spec = GCMParameterSpec(128, convertStringToByte(data[1]))


        cipher.init(Cipher.DECRYPT_MODE, key, spec)


        val decryptedValue64 = Base64.decode(data[0], Base64.NO_PADDING)
        val decryptedByteValue = cipher.doFinal(decryptedValue64)
        return String(decryptedByteValue, charset("utf-8"))
    }

    fun convertStringToByte(string: String): ByteArray {
        val out = ByteArray(string.length)
        for (i in 0 until string.length) {
            out[i] = string[i].toByte()
        }

        return out
    }

    @Throws(NoSuchAlgorithmException::class, UnrecoverableEntryException::class, KeyStoreException::class)
    private fun getDecryptKey(alias: String): Key {

        var keyStore = KeyStore.getInstance(ANDROID_KEY_STORE);
        keyStore.load(null);

        return (keyStore.getEntry(alias, null) as KeyStore.SecretKeyEntry).secretKey
    }
}



