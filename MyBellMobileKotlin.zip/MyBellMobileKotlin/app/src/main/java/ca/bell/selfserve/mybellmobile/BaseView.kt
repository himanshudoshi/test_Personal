package ca.bell.selfserve.mybellmobile.base

/**
 * Created by Gaurav Gupta
 * This is a base class of view contract between view class and it's presenter
 */
interface BaseView<T> {
    fun attachPresenter()
}