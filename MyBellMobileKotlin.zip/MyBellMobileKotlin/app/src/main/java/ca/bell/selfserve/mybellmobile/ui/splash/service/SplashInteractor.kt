package ca.bell.selfserve.mybellmobile.ui.splash.service

import ca.bell.selfserve.data.network.api.SplashApi
import ca.bell.selfserve.data.network.model.ApiConstant
import ca.bell.selfserve.data.network.model.NetworkBaseCallback
import ca.bell.selfserve.mybellmobile.BellApp

import ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile.CustomerProfileResponse
import ca.bell.selfserve.mybellmobile.ui.splash.model.ConfigurationResponse
import ca.bell.selfserve.utility.AppLog
import com.google.gson.Gson

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
class SplashInteractor(private val mSplashInteractorCallbacks: SplashInteractorCallbacks)   {

    val splashApi: SplashApi = SplashApi()

    fun callConfigurationApi() {
//        val configurationWSM = ConfigurationWSM()
//        Repository.getNewInstance(AppConstant.DataConstant.CONFIGURATION, configurationWSM).setBaseCallback(this).execute()


        splashApi.callConfigApi(getConfigCallback())

    }

    private fun getConfigCallback(): NetworkBaseCallback {
        return object :NetworkBaseCallback{
            private lateinit var configurationResponse: ConfigurationResponse

            override fun onSuccessfulResponse(data: Any?,headers: Map<String, ArrayList<String>>) {
                AppLog.info("Config success")
                if (data != null) {
                    val response = data.toString()
                    BellApp.getInstance().getSharedPreference().setValue(ApiConstant.GET_CONFIG_KEY, data.toString())
                    configurationResponse = Gson().fromJson(response, ConfigurationResponse::class.java)

                    mSplashInteractorCallbacks.onConfigurationResponse(configurationResponse as ConfigurationResponse)
                }
            }

            override fun onFailure(response: Any?) {
                mSplashInteractorCallbacks.onConfigurationFailure(response)
                /*AppLog.info("Config failure");
                String fromPreference = BellApp.getInstance().getSharedPreference().getStringValue(ApiConstant.GET_CONFIG_KEY, null);
                if (!TextUtils.isEmpty(fromPreference)) {
                    configurationResponse = new Gson().fromJson(fromPreference, ConfigurationResponse.class);
                    mConfigurationCallback.onConfigurationResponse(configurationResponse);
                }*/
            }
        }
    }


    interface SplashInteractorCallbacks {

        fun onBUPCustomerProfileFailure(response: Any)

        fun onAuthenticationFailure(o: Any)

        fun onConfigurationResponse(parsedData: ConfigurationResponse)

        fun onBUPCustomerProfileSuccess(parsedData: CustomerProfileResponse)

        fun onAuthenticationSuccess(parsedData: Any)

        fun onConfigurationFailure(response: Any?)
    }


}
