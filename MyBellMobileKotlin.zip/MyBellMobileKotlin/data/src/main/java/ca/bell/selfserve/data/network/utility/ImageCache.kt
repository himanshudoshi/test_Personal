package ca.bell.selfserve.data.network.utility

import com.android.volley.toolbox.NetworkImageView

import ca.bell.selfserve.data.DataSingleton
import ca.bell.selfserve.data.network.model.ImageCacheCallback

/**
 * Created by GG00539076 on 4/10/2018.
 */

class ImageCache {

    fun loadImage(url: String, imageLoaderCallback: ImageCacheCallback) {
        val volleyHelper = DataSingleton.getDataSingleton().getVolleyHelperImpl()
        volleyHelper.loadImage(url, imageLoaderCallback)
    }

    fun loadImage(url: String, networkImageView: NetworkImageView) {
        val volleyHelper = DataSingleton.getDataSingleton().getVolleyHelperImpl()
        volleyHelper!!.loadImage(url, networkImageView)
    }

}
