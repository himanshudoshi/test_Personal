package ca.bell.nmf.ui.view

import android.content.Context
import android.content.res.Resources
import android.support.test.rule.ActivityTestRule
import ca.bell.nmf.activities.TestActivity
import ca.bell.nmf.ui.R
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test

/**
 * Created on 7/26/2018.
 */
class ShortHeaderTopbarTest {


    @Rule
    @JvmField
    val mActivityRule: ActivityTestRule<TestActivity> = ActivityTestRule<TestActivity>(TestActivity::class.java)

    private lateinit var mTestActivity: TestActivity
    private lateinit var resources: Resources
    private lateinit var context: Context
    private var toolbar: ShortHeaderTopbar? = null


    @Before
    fun setUp() {
        mTestActivity= mActivityRule.activity
        context = mTestActivity
        resources = mTestActivity.baseContext.resources
        toolbar = ShortHeaderTopbar(mTestActivity)

        toolbar!!.setSupportActionBar(mTestActivity)
    }

    @Test
    fun changeTitle() {
        val title = "title"
        val titleNegative = "title_negative"

        toolbar!!.title = title

//        positive test case
        Assert.assertEquals(title, toolbar!!.title)

//        positive test case
        Assert.assertNotEquals(titleNegative, toolbar!!.title)
    }

    @Test
    fun changeSubtitle() {
        val subtitle = "subtitle"
        val subNegative = "title_negative"
        toolbar!!.subtitle = subtitle
//        positive test case
        Assert.assertEquals(subtitle , toolbar!!.subtitle)
//        positive test case
        Assert.assertNotEquals(subNegative, toolbar!!.subtitle)
    }


    @Test
    fun changeNavigationIcon() {
        val navigationIconId = R.drawable.arrow_left
        val falseNavigationIconId = R.drawable.icon_earth
        val navigationIcon = context.getDrawable(navigationIconId)
        val falseNavigationIcon = context.getDrawable(falseNavigationIconId)
        toolbar!!.navigationIcon= navigationIcon
//        positive test case
        Assert.assertEquals(navigationIcon , toolbar!!.navigationIcon)
        Assert.assertNotEquals(falseNavigationIcon, toolbar!!.navigationIcon)
    }


    @Test
    fun changeLogoIcon() {
        val logoIconId = R.drawable.arrow_left
        val falseLogoIconId = R.drawable.icon_earth
        val logoIcon = context.getDrawable(logoIconId)
        val falseLogoIcon = context.getDrawable(falseLogoIconId)
        toolbar!!.logo= logoIcon
//        positive test case
        Assert.assertEquals(logoIcon , toolbar!!.logo)
        Assert.assertNotEquals(falseLogoIcon, toolbar!!.logo)
    }






}