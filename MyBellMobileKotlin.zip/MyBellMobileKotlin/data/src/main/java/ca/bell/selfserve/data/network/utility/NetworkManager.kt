package ca.bell.selfserve.data.network.utility

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import ca.bell.selfserve.data.network.model.NetworkType
import java.io.IOException


/**
 * Created by GG00539076 on 5/22/2018.
 */

class NetworkManager {

    val context: Context;

    private constructor(context: Context) {
        this.context = context
    }


    fun isOnline(): Boolean {
        var cm: ConnectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.getActiveNetworkInfo()
        return netInfo != null && netInfo!!.isConnectedOrConnecting()
    }


    fun isNetworkReachable(): Boolean {
        val runtime = Runtime.getRuntime()
        try {
            val ipProcess = runtime.exec("/system/bin/ping -c 1 8.8.8.8")
            val exitValue = ipProcess.waitFor()
            return exitValue == 0
        } catch (e: IOException) {
            e.printStackTrace()
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
        return false
    }


    var networkType: NetworkType?
        get() {
            return networkType
        }
        set(value) {
//             some business logic
            this.networkType = value
        }


    companion object {

        private var initialised = false
        private lateinit var instance: NetworkManager

        fun getNetworkManager(): NetworkManager {
            return instance
        }

        fun init(context: Application) {
            if (context == null || initialised) return
            initialised = true
            instance = NetworkManager(context)
        }
    }

}


