package ca.bell.selfserve.data.network.utility

import com.google.gson.Gson

/**
 * Created by GG00539076 on 5/23/2018.
 */

class NetworkUtility {


    fun getGson(_object: Any): String {
        return Gson().toJson(_object)
    }


}
