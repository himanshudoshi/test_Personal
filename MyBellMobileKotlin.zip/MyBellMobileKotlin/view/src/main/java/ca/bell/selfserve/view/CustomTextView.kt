package ca.bell.selfserve.mybellmobile.customview

/**
 * Created by GG00495581 on 10/24/2017.
 */

import android.content.Context
import android.graphics.Typeface
import android.support.v7.widget.AppCompatTextView
import android.util.AttributeSet
import ca.bell.selfserve.view.R

class CustomTextView : AppCompatTextView {

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle) {
        init(attrs)
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init(attrs)

    }

    constructor(context: Context) : super(context) {
        init(null)
    }

    private fun init(attrs: AttributeSet?) {
        if (attrs != null) {
            try {
                val a = context.obtainStyledAttributes(attrs, R.styleable.CustomTextView)
                val fontName = a.getString(R.styleable.CustomTextView_fontName)
                val myTypeface = Typeface.createFromAsset(context.assets, "fonts/Helvetical.otf")
                typeface = myTypeface
                a.recycle()
            }catch(e : Exception ) {
                e.printStackTrace()
            }
        }
    }

}