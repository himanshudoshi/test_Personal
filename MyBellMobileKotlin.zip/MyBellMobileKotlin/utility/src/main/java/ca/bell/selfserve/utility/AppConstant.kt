package ca.bell.selfserve.utility


object AppConstant {



    interface languageNames {
        companion object {
            val ENGLISH = "en"
            val FRENCH = "fr"
        }
    }

    interface flavourType {
        companion object {
            val BELL = "BELL"
            val VIRGIN = "VIRGIN"
        }
    }

    interface userType {
        companion object {
            val BUP = "BUP"
        }
    }


    // Constants for customer accounts
    interface AccoountNames {
        companion object {
            val PREPAID = "prepaid"
            val ONE_BILL = "onebill"
            val COMBINATIONAL = "combinational"
            val MOBILITY = "mobility"
        }
    }

    // type of accounts
    interface TypeOfAccount {
        companion object {
            val MOBILITY = "mobility"
            val INTERNET = "internet"
            val WIRELINE = "wireline"
            val TV = "tv"
            val IPTV = "iptv"
        }

    }

    // Constants for events for webview
    object WebViewConstants {
        val WEBVIEW_FINISHED_LOADING = "webViewFinishedLoading"
        val PLATFORM_NO_BUP_NSI_SUCCESS = "platformNoBUPNSISuccessReceived"
        val HIDE_LOADER = "HideLoader"
        val WEBVIEW_CLOSED = "WebViewClosed"
        val WEBVIEW_HARDWARE_BACK_BUTTON = "WebviewHardwareBackButton"
        val BUP_USER = "BUP"
        val NSI_USER = "NSI"
        val USAGE_TAB = "Usage"
        val BILLS_TAB = "Bills"
        val SUPPORT_TAB = "Support"
        val MORE_TAB = "More"
        val LOGOUT = "Logout"
        val BASE_WEB_VIEW = "baseWebView"
        val APP_CLOSE = "AppClose"
        val USER_DATA_FETCHED = "UserData"
        val USER_NAME = "Username"
    }

    interface DataConstant {
        companion object {
            val BUP_AUTH = 1
            val BUP_CUST_PROFILE = 2
            val CONFIGURATION = 3
            val PLATFORM_AUTH = 4
            val LOGOUT = 5
            val PAYMENT = 6
        }
    }


    interface ApiErrorCodes {
        companion object {
            val ERROR_401 = 401
            val ERROR_123 = -123
            val ERROR_124 = -124
            val ERROR_128 = -128
            val ERROR_505 = 505
            val ERROR_133 = -133
            val ERROR_205 = -205
            val ERROR_232 = -232
            val ERROR_233 = -233
        }
    }


    interface DBConstants {
        companion object {
            val IS_CUSTOMER_PROFILE_SAVED_IN_DB = "isCustomerProfileSavedInDB"
        }

    }

    interface SharedPrefrencesConstants {
        companion object {
            val APPLICATION_INSTALLATION_TIME = "ApplicationInstallationTime"
        }

    }


}
