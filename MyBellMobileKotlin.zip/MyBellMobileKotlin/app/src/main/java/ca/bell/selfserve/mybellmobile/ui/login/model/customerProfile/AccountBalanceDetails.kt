package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

import com.google.gson.annotations.SerializedName

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
data class AccountBalanceDetails(

        @field:SerializedName("adjustmentDetails")
        val adjustmentDetails: List<AdjustmentDetailsItem?>? = null,

        @field:SerializedName("totalAmount")
        val totalAmount: Double? = null,

        @field:SerializedName("billingDate")
        val billingDate: Long? = null,

        @field:SerializedName("balance")
        val balance: Double? = null,

        @field:SerializedName("paymentSummaryAmount")
        val paymentSummaryAmount: Double? = null,

        @field:SerializedName("adjustmentSummaryAmount")
        val adjustmentSummaryAmount: Double? = null,

        @field:SerializedName("refundDetails")
        val refundDetails: List<Any?>? = null,

        @field:SerializedName("adjustmentIndicator")
        val adjustmentIndicator: String? = null,

        @field:SerializedName("paymentDetails")
        val paymentDetails: List<PaymentDetailsItem?>? = null,

        @field:SerializedName("paymentIndicator")
        val paymentIndicator: String? = null
)