package ca.bell.selfserve.mybellmobile.ui.splash.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
class ForceUpgradeCMSContent {

    @SerializedName("language")
    @Expose
    var language: String? = null
    @SerializedName("title")
    @Expose
    var title: String? = null
    @SerializedName("message")
    @Expose
    var message: String? = null
    @SerializedName("OkBtn")
    @Expose
    var okBtn: String? = null
    @SerializedName("CancelBtn")
    @Expose
    var cancelBtn: String? = null


}

