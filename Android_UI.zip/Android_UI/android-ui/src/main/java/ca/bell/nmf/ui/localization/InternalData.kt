package ca.bell.nmf.ui.localization

import android.content.Context

/**
 * This class is used to store key-values data of the application.
 * This class manages the SharedPreferences of the app.
 */
class InternalData(context: Context) {

    /**
     * @property sharedPreferences gets the interface of SharedPreferences for the app, and will use it
     * to operate data concerning the app.
     */
    private val sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCE_NAME, Context.MODE_PRIVATE)

    /**
     * @property editor gets the Interface of editor for the SharedPreferences and is used
     * to operate data for the app.
     */
    private val editor = sharedPreferences.edit()

    companion object {
        /**
         * @property CURRENT_LANGUAGE_KEY const key to keep the value for current language
         */
        const val CURRENT_LANGUAGE_KEY = "CURRENT_LANGUAGE"

        /**
         * @property SHARED_PREFERENCE_NAME const key to define the file name of SharedPreferences
         */
        private const val SHARED_PREFERENCE_NAME = "NMF_INTERNAL_DATA"

        /**
         * @property SHOULD_SHOW_LANGUAGE_SELECT_DIALOG key flag to manaeg if we should prompt the change language
         * dialog for the user. If "true", we should show the dialog.
         */
        const val SHOULD_SHOW_LANGUAGE_SELECT_DIALOG = "SHOULD_SHOW_LANGUAGE_SELECT_DIALOG"

        /**
         * @property DEVICE_LANGUAGE_KEY const key to keep the value existing DEVICE language locale, BEFORE any
         * activity of the app will start.
         */
        const val DEVICE_LANGUAGE_KEY = "DEVICE_LANGUAGE_KEY"
    }

    /**
     * This method reads the shared preferences file, and returns the value of Locale Lang in case if it exists, or empty otherwise.
     * @return String
     */
    fun getCurrentLanguage(): String {
        return sharedPreferences.getString(CURRENT_LANGUAGE_KEY, "") ?: ""
    }

    /**
     * This method stores the Locale Lang selected by the User in the SharedPreferences of the app.
     * @param language takes the String "en" or "fr" as a value.
     */
    fun storeUserPreference(key: String, value: String) {
        editor.putString(key, value)
                .commit()
    }

    fun getUserPreference(key: String, defaultValue: String): String {
        return sharedPreferences.getString(key, defaultValue) ?: ""
    }

    /**
     * This method reads the shared preferences file, and returns the value of Locale Lang in case if it exists, or empty otherwise.
     * @return String
     */
    fun getUserPreference(key: String, defaultValue: Boolean): Boolean {
        return sharedPreferences.getBoolean(key, defaultValue)
    }

    /**
     * This method stores an User preference in the SharedPreferences of the app.
     * @param key takes the KEY.
     * @param value takes the provided value
     */
    fun storeUserPreference(key: String, value: Boolean) {
        editor.putBoolean(key, value)
                .commit()
    }
}