package ca.bell.selfserve.mybellmobile.exception


interface IExceptionHandler {
    fun onUncaughtException(thread: Thread, ex: Throwable)

}