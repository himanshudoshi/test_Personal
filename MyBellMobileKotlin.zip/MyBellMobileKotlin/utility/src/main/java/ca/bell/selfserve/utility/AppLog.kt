package ca.bell.selfserve.utility

import android.util.Log


/**
 * Created by Gaurav Gupta on 4/9/17.
 * method to print the data in log
 */
object AppLog {
    val apptype: String = "MBM"

    /**
     * method to print the message as debug message
     *
     * @param value
     */
    fun debug(value: String) {
        if (BuildConfig.DEBUG)
            Log.d(getTag(), value)
    }

    private fun getTag(): String? {
        return AppLog.javaClass.canonicalName
    }

    /**
     * method to print the message as debug message
     *
     * @param value
     */
    fun info(value: String) {
        if (BuildConfig.DEBUG)
            Log.d(getTag(), value)
    }

    /**
     * method to print the error message as an error
     *
     * @param value
     */
    fun error(value: String) {
        if (BuildConfig.DEBUG)
            Log.e(getTag(), value)
    }


}
