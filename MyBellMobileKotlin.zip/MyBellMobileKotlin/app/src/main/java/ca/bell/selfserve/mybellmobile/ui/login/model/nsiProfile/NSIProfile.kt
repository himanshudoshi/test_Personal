package ca.bell.selfserve.mybellmobile.ui.login.model.nsiProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
class NSIProfile {
    private val subId: String? = null
    private val language: String? = null
    private val accountSubType: String? = null

}
