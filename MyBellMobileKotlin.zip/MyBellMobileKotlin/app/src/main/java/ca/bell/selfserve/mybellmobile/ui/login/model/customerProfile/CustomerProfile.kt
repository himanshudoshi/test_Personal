package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName
data class CustomerProfile(

        @field:SerializedName("passwordChangeDate")
        val passwordChangeDate: Long? = null,

        @field:SerializedName("lastLogin")
        val lastLogin: Long? = null,

        @field:SerializedName("contactName")
        val contactName: ContactName? = null,

        @field:SerializedName("language")
        val language: Language? = null,

        @field:SerializedName("marketingID")
        val marketingID: Any? = null,

        @field:SerializedName("userName")
        val userName: String? = null,

        @field:SerializedName("createdOn")
        val createdOn: Long? = null,

        @field:SerializedName("secretAnswer")
        val secretAnswer: Any? = null,

        @field:SerializedName("organizationID")
        val organizationID: Any? = null,

        @field:SerializedName("modifiedOn")
        val modifiedOn: Long? = null,

        @field:SerializedName("activeHouseholdOrders")
        val activeHouseholdOrders: Any? = null,

        @field:SerializedName("emailAddress")
        val emailAddress: String? = null,

        @field:SerializedName("recoveryMobileNumber")
        val recoveryMobileNumber: Any? = null,

        @field:SerializedName("profileType")
        val profileType: String? = null,

        @field:SerializedName("legacyAccounts")
        val legacyAccounts: LegacyAccounts? = null,

        @field:SerializedName("userSecretQuestions")
        val userSecretQuestions: Any? = null,

        @field:SerializedName("recoveryEMailAddress")
        val recoveryEMailAddress: Any? = null,

        @field:SerializedName("profileUpdateDate")
        val profileUpdateDate: Long? = null,

        @field:SerializedName("guid")
        val guid: String? = null,

        @field:SerializedName("oneBillAccounts")
        val oneBillAccounts: OneBillAccounts? = null
)