package ca.bell.selfserve.mybellmobile.ui.login.presenter

/**
 * Created by AU00538779 on 5/4/2018.
 */

import android.support.v4.app.LoaderManager

import ca.bell.selfserve.mybellmobile.base.ExceptionHandlerInterface
import ca.bell.selfserve.utility.AppConstant
import ca.bell.selfserve.utility.AppLog
import ca.bell.selfserve.mybellmobile.common.ErrorHandler
import ca.bell.selfserve.mybellmobile.common.Utility
import ca.bell.selfserve.mybellmobile.ui.login.LoginContract
import ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile.CustomerProfileResponse
import ca.bell.selfserve.mybellmobile.ui.login.service.LoginInteractor
//import ca.bell.selfserve.mybellmobile.modules.registrationRecovery.Service.RegistratationInteractor

//import ca.bell.selfserve.mybellmobile.webview.SendEventClass

class LoginPresenter : LoginContract.ILoginPresenter, LoginInteractor.LoginInteractorCallback, ExceptionHandlerInterface {
//        ,RegistratationInteractor.RegistrationInteractorCallback {

    private var iLoginView: LoginContract.ILoginView? = null
    private var mLoaderManager: LoaderManager? = null
    private var mLoginInteractor: LoginInteractor? = null
    private var mLoginErrorHandler: ErrorHandler? = null

    override fun startBUPAuthentication(userName: String, password: String) {
        if (Utility.checkNullString(userName)) {
            iLoginView!!.setUsernameError()
        } else if (Utility.checkNullString(password)) {
            iLoginView!!.setPasswordError()
        } else {
            authenticateUser(userName, password)
        }
    }

    override fun onRegisterClick() {
//        iLoginView!!.hideProgress()
        // TODO Uncomment this
//        val jsessionid = NetworkConfiguration.getInstance().getJSESSIONID()
//        if (!TextUtils.isEmpty(jsessionid))
//            BellApp.getInstance().getAppWebView().setJsessionId()
//        else
//            authenticatePlatform()

        iLoginView!!.navigateToRegisterFlow()
    }

    private fun authenticatePlatform() {
        // TODO Uncomment this
//        val registratationInteractor = RegistratationInteractor(this, null)
//        registratationInteractor.authenticatePlatform()
    }

    override fun onRecoveryClick() {
        iLoginView!!.navigateToRecoveryFlow()
    }

    override fun authenticateUser(userName: String, password: String) {
//        iLoginView!!.showProgress()

        mLoginInteractor!!.authenticateUser(userName, password)
    }

    override fun attachView(view: Any) {
        iLoginView = view as LoginContract.ILoginView
    }

    override fun detachView() {
        this.iLoginView = null
    }

    override fun attachLoader(loaderManager: LoaderManager) {
        this.mLoaderManager = loaderManager
        mLoginInteractor = LoginInteractor(this)
        mLoginErrorHandler = ErrorHandler()
    }

    override  fun onAuthenticationSuccess(data: Any) {
        AppLog.debug("onAuthentication success in presenter.")
        mLoginInteractor!!.requestCustomerProfileData()
    }

    override  fun onAuthenticationFailure(data: Any) {
//        iLoginView!!.hideProgress()
        mLoginErrorHandler!!.handleAuthenticationFailure(this, data)
    }

    override  fun onBUPCustomerProfileSuccess(customerProfileResponse: CustomerProfileResponse) {
//        iLoginView!!.hideProgress()
        /* BellApp.getInstance().getAppWebView().loadUrl(SendEventClass.sendEvent(AppConstant.WebViewConstants.BUP_USER));*/
//        iLoginView!!.navigateToHome()

    }

    override  fun onBUPCustomerProfileFailure(failure: Any) {
//        iLoginView!!.hideProgress()
        AppLog.debug("Bup Customer Profile Failure")
    }

    fun onPlatformAuthenticateSuccess() {
//        BellApp.getInstance().getAppWebView().setJsessionId()
//        BellApp.getInstance().getAppWebView().loadUrl(SendEventClass.sendEvent(AppConstant.WebViewConstants.PLATFORM_NO_BUP_NSI_SUCCESS))
        AppLog.debug(AppConstant.WebViewConstants.PLATFORM_NO_BUP_NSI_SUCCESS + " is called")
    }

    override fun onGettingException(value: Int) {
        iLoginView!!.showErrorDialog(value)
    }
}
