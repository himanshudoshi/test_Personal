package ca.bell.selfserve.mybellmobile.ui.login.view

import android.app.Dialog
import android.content.Context
import android.content.res.Resources
import android.os.Bundle
import android.text.Html
import android.view.View
import android.view.View.OnClickListener
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import ca.bell.selfserve.mybellmobile.BellApp
import ca.bell.selfserve.mybellmobile.R
import ca.bell.selfserve.mybellmobile.alertdialog.IErrorDialogListner
import ca.bell.selfserve.mybellmobile.base.BaseActivity
import ca.bell.selfserve.utility.AppConstant
import ca.bell.selfserve.utility.AppLog
import ca.bell.selfserve.mybellmobile.common.Utility

import ca.bell.selfserve.mybellmobile.dialog.progressdialog.BellProgressDialog
import ca.bell.selfserve.mybellmobile.ui.login.LoginContract
import ca.bell.selfserve.mybellmobile.ui.login.presenter.LoginPresenter

class LoginActivity : BaseActivity(), LoginContract.ILoginView, OnClickListener {
    private var mEditTextUserName: EditText? = null
    private var mEditTextPassword: EditText? = null
    private var mContext: Context? = null
    private var iLoginPresenter: LoginPresenter? = null
    private var mSwitchKeepMeLoggedIn: Switch? = null
    private var mDialogProgress: BellProgressDialog? = null
    private val senchaLoaded = false
    private val isRegisterClicked: Boolean = false
    private var mResources: Resources? = null


    override val editTextPassword: String
        get() = mEditTextPassword!!.text.toString()

    override val keepMeState: Boolean
        get() = mSwitchKeepMeLoggedIn!!.isChecked

    override val context: Context
        get() = this

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = this@LoginActivity
        mResources = resources
        setContentView(R.layout.activity_login)
        // sencha -start
        /*      LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("senchaLoaded"));*/

        // sencha - end
        //attach splash presenter to splash view
        attachPresenter()
        mDialogProgress = BellProgressDialog.getInstance(this)
        initComp()
        regList()
    }


    // sencha - start
    /*private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            senchaLoaded = true;
            if (isRegisterClicked)
                iLoginPresenter.onRegisterClick();
        }
    };
*/
    // sencha - end
    override fun attachPresenter() {
        if (iLoginPresenter == null) {
            iLoginPresenter = LoginPresenter()
        }
        iLoginPresenter!!.attachView(this)
        iLoginPresenter!!.attachLoader(this.supportLoaderManager)
    }


    override fun onRetainCustomNonConfigurationInstance(): Any? {
        return iLoginPresenter
    }

    private fun regList() {
        findViewById<View>(R.id.register).setOnClickListener(this)
        findViewById<View>(R.id.login).setOnClickListener(this)
        val recoveryText: TextView = findViewById<TextView>(R.id.recovery)
        recoveryText.setOnClickListener(this)
        recoveryText.setText(Html.fromHtml(getString(R.string.login_recoveryButton)))
    }

    private fun initComp() {
        mEditTextUserName = findViewById(R.id.username)
        mEditTextPassword = findViewById(R.id.password)
        mSwitchKeepMeLoggedIn = findViewById(R.id.switch1)
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.register -> {
            }

            R.id.login -> {
                //saving the user name in sharedpreference
//                BellApp.getInstance().getSharedPreference().setEncryptedValue(AppConstant.WebViewConstants.USER_NAME, mEditTextUserName!!.text.toString())
                 BellApp.getInstance().getSharedPreference().setValue(          AppConstant.WebViewConstants.USER_NAME, mEditTextUserName!!.getText().toString());

                AppLog.debug("Register button clicked.")
                iLoginPresenter!!.startBUPAuthentication(mEditTextUserName!!.text.toString(), editTextPassword)
            }

            R.id.recovery -> {
            }
        }/*    isRegisterClicked = true;
                if (senchaLoaded) {
                    AppLog.debug("Register button clicked.");
                    iLoginPresenter. ();
                } else
                    showProgress();*//* if (senchaLoaded) {
                    AppLog.debug("Register button clicked.");
                    iLoginPresenter.onRecoveryClick();
                } else
                    showProgress();*/
    }

    override fun showProgress() {
        mDialogProgress?.showDialog()
    }

    override fun hideProgress() {
        mDialogProgress?.hideDialog()
    }

    override fun setUsernameError() {
        val resources = resources
        Utility.showErrorSingleButton(
                mContext!!,
                resources.getString(R.string.login_wrongUserPass),
                resources.getString(R.string.login_enterUserName),
                resources.getString(R.string.close),
                object : IErrorDialogListner {
                    override fun onOkButtonPressed(customDialog: Dialog) {

                    }

                    override fun onCancelButtonPressed(customDialog: Dialog) {

                    }
                }
        )
    }

    override fun setPasswordError() {
        val resources = resources
        Utility.showErrorSingleButton(mContext!!, resources.getString(R.string.login_wrongUserPass),
                resources.getString(R.string.login_enterPassword), resources.getString(R.string.close), object : IErrorDialogListner {
            override fun onOkButtonPressed(customDialog: Dialog) {

            }

            override fun onCancelButtonPressed(customDialog: Dialog) {

            }
        })
    }

    override fun navigateToHome() {
        AppLog.debug("navigateToHome")
//        hideProgress()
//        val intent = Intent(this, LandingActivity::class.java)
//        //        intent.putExtra("UserName", BellApp.getInstance().getSharedPreference().getStringValue(AppConstant.WebViewConstants.USER_NAME, null));
//        intent.putExtra("UserName", BellApp.getInstance().getSharedPreference().getDecryptedValue(AppConstant.WebViewConstants.USER_NAME, null))
//        startActivity(intent)
//        finish()

        //Toast.makeText(this,"Login Successfull.Navingating to home",Toast.LENGTH_SHORT).show();
    }

    override fun navigateToRecoveryFlow() {
        /* AppLog.debug("navigateToRecoveryFlow");
        Intent RecoveryView = new Intent(mContext, RegistrationRecovery.class);
        RecoveryView.putExtra("Event", "Recovery");
        mContext.startActivity(RecoveryView);*/

    }

    override fun navigateToRegisterFlow() {
        /* AppLog.debug("navigateToRegisterFlow");
        Intent RegisterView = new Intent(mContext, RegistrationRecovery.class);
        RegisterView.putExtra("Event", "Register");
        mContext.startActivity(RegisterView);
*/
    }

    override fun showErrorDialog(key: Int) {
        when (key) {
            AppConstant.ApiErrorCodes.ERROR_401 ->

                Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_wrongUserPass),
                        mResources!!.getString(R.string.login_bupLoginFailed), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                    override fun onOkButtonPressed(customDialog: Dialog) {

                    }

                    override fun onCancelButtonPressed(customDialog: Dialog) {

                    }
                })
            AppConstant.ApiErrorCodes.ERROR_123 -> Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_wrongUserPass),
                    mResources!!.getString(R.string.login_bupLoginFailed), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                override fun onOkButtonPressed(customDialog: Dialog) {

                }

                override fun onCancelButtonPressed(customDialog: Dialog) {

                }
            })
            AppConstant.ApiErrorCodes.ERROR_128 -> Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_wrongUserPass),
                    mResources!!.getString(R.string.login_bupLoginFailed), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                override fun onOkButtonPressed(customDialog: Dialog) {

                }

                override fun onCancelButtonPressed(customDialog: Dialog) {

                }
            })
            AppConstant.ApiErrorCodes.ERROR_124 ->

                Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_nsiAuthFailedTitle),
                        mResources!!.getString(R.string.login_netAuthFailed), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                    override fun onOkButtonPressed(customDialog: Dialog) {

                    }

                    override fun onCancelButtonPressed(customDialog: Dialog) {

                    }
                })
            AppConstant.ApiErrorCodes.ERROR_505 ->

                Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_netError),
                        mResources!!.getString(R.string.login_netConnectionFailed), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                    override fun onOkButtonPressed(customDialog: Dialog) {

                    }

                    override fun onCancelButtonPressed(customDialog: Dialog) {

                    }
                })
            AppConstant.ApiErrorCodes.ERROR_133 ->

                Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_prepaidUnSupportedTitle),
                        mResources!!.getString(R.string.login_prepaidUnSupportedMsg), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                    override fun onOkButtonPressed(customDialog: Dialog) {

                    }

                    override fun onCancelButtonPressed(customDialog: Dialog) {

                    }
                })
            AppConstant.ApiErrorCodes.ERROR_205 ->

                Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_accountLocked),
                        mResources!!.getString(R.string.login_accountLockedFullMsg), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                    override fun onOkButtonPressed(customDialog: Dialog) {

                    }

                    override fun onCancelButtonPressed(customDialog: Dialog) {

                    }
                })

        // TODO: 9/19/2017 outage is pending
            AppConstant.ApiErrorCodes.ERROR_232 ->

                Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_netError),
                        mResources!!.getString(R.string.login_netConnectionFailed), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                    override fun onOkButtonPressed(customDialog: Dialog) {

                    }

                    override fun onCancelButtonPressed(customDialog: Dialog) {

                    }
                })
        // TODO: 9/19/2017 outage is pending
            AppConstant.ApiErrorCodes.ERROR_233 ->

                Utility.showErrorSingleButton(mContext!!, mResources!!.getString(R.string.login_netError),
                        mResources!!.getString(R.string.login_netConnectionFailed), mResources!!.getString(R.string.close), object : IErrorDialogListner {
                    override fun onOkButtonPressed(customDialog: Dialog) {

                    }

                    override fun onCancelButtonPressed(customDialog: Dialog) {

                    }
                })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        iLoginPresenter!!.detachView()
        //LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
    }
}
