package ca.bell.selfserve.data.network.model

/**
 * Created by GG00539076 on 4/3/2018.
 */

enum class Priority {
    LOW, NORMAL, IMMEDIATE, HIGH
}