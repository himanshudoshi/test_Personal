package ca.bell.selfserve.mybellmobile.alertdialog

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import ca.bell.selfserve.utility.R

class BellErrorDialog(var context:Context, var appDialog: AppDialog, val errorListner: IErrorDialogListner) {

    fun showDialog(){
        val mCustomDialog = Dialog(context)
        mCustomDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        mCustomDialog.setContentView(R.layout.dialog_error)
        mCustomDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        mCustomDialog.setCanceledOnTouchOutside(false)

        val onButton = mCustomDialog.findViewById<Button>(R.id.btnOkDialog) as Button
        val cancelButton = mCustomDialog.findViewById<Button>(R.id.btnCancelDialog) as Button
        val dialogMessage = mCustomDialog.findViewById<TextView>(R.id.tv_message_dialogue) as TextView
        val dialogTitle = mCustomDialog.findViewById<TextView>(R.id.title) as TextView
        val divider = mCustomDialog.findViewById<View>(R.id.divider) as View
        onButton.text = appDialog.okBtnText
        cancelButton.text = appDialog.cancelBtnText
        dialogMessage.setText(appDialog.message)
        dialogTitle.setText(appDialog.title)
        onButton.setTransformationMethod(null)
        cancelButton.setTransformationMethod(null)

        if (appDialog.hideTitle) {
            dialogTitle.visibility = View.GONE
            divider.visibility = View.GONE
        }
        if (appDialog.hideOkButton) {
            onButton.visibility = View.GONE
        }
        if (appDialog.hideCancelButton) {
            cancelButton.visibility = View.GONE
        }
        if (appDialog.hasSmallBtn) {
            cancelButton.setLayoutParams(LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }


        onButton.setOnClickListener {
            mCustomDialog.dismiss()
            errorListner.onOkButtonPressed(mCustomDialog)
        }
        cancelButton.setOnClickListener{
            mCustomDialog.dismiss()
            errorListner.onCancelButtonPressed(mCustomDialog)
        }


        mCustomDialog.show()




    }
}