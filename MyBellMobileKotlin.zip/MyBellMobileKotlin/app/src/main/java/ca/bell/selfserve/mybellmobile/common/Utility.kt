package ca.bell.selfserve.mybellmobile.common

import android.content.Context
import android.net.ConnectivityManager
import android.text.Html
import android.text.Spanned
import android.text.TextUtils
import android.view.Gravity
import android.widget.Toast
import ca.bell.selfserve.data.network.model.ApiConstant

import org.json.JSONException
import org.json.JSONObject

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

import ca.bell.selfserve.mybellmobile.BellApp
import ca.bell.selfserve.mybellmobile.alertdialog.AppDialog
import ca.bell.selfserve.mybellmobile.alertdialog.BellErrorDialog
import ca.bell.selfserve.mybellmobile.alertdialog.IErrorDialogListner
import ca.bell.selfserve.utility.AppLog

//import ca.bell.selfserve.mybellmobile.dialog.errordialog.AppDialog
//import ca.bell.selfserve.mybellmobile.dialog.errordialog.BellErrorDialog
//import ca.bell.selfserve.mybellmobile.dialog.errordialog.IErrorDialogListner
//import ca.bell.selfserve.data.network.model.NetworkConfiguration
//import ca.bell.selfserve.mybellmobile.sharedpreferences.SharedPreferenceManager
//import ca.bell.selfserve.mybellmobile.webview.AppWebView


object Utility {

    /**
     * method to get language from locale
     *
     * @return language from locale
     */
    val deviceLanguageFromLocale: String
        get() = Locale.getDefault().language

    val credentials: JSONObject?
        get() {
            AppLog.debug("getCredentials function called")
            var jsonObject: JSONObject? = null
            val sharedPreference = BellApp.getInstance().getSharedPreference()
            val credentials = sharedPreference.getStringValue(ApiConstant.CREDENTIALS)
            AppLog.debug("getCredentials credentials are " + credentials!!)
            if (credentials == null || credentials == "") {
                AppLog.debug("getCredentials is false")
                return null
            } else {
                try {
                    jsonObject = JSONObject(credentials)
                    AppLog.debug("getCredentials is true")
                    return jsonObject
                } catch (e: JSONException) {
                    e.printStackTrace()
                }

            }
            return jsonObject
        }


    fun isNetworkAvailable(mContext: Context): Boolean {
        val connectivityManager = mContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnected
    }

//    fun showErrorSingleButton(mContext: Context, title: String, message: String, btnText: String, iErrorDialogListner: IErrorDialogListner) {
//        val appDialog = AppDialog.AppDialogBuilder(title, message)
//                .setcancelBtnText(btnText)
//                .sethideOkButton(true)
//                .sethasSmallBtn(true)
//                .build()
//        BellErrorDialog(mContext, appDialog, iErrorDialogListner).showErrorDialog()
//
//    }

    fun showToast(message: String) {
        val mContext = BellApp.getInstance()
        val toast = Toast.makeText(mContext, message, Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.BOTTOM, 0, 0)
        toast.show()
    }

    fun isKeepMeValid(serverDate: String): Boolean {
        AppLog.error("getDateAgo called ")
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        var days: Long = 0
        try {
            val date = sdf.parse(serverDate)
            val now = Date(System.currentTimeMillis())
            days = getDateDiff(date, now, TimeUnit.DAYS)
            if (days >= 120) {
                AppLog.error("getDateAgo No of days are mode than 120$days")
                return false
            }
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        AppLog.error("getDateAgo No of days are $days")
        return true
    }

    private fun getDateDiff(date1: Date, date2: Date, timeUnit: TimeUnit): Long {
        val diffInMillies = date2.time - date1.time
        return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS)
    }

    fun setHTML(data: String): Spanned {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            Html.fromHtml(data, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(data)
        }
    }


    fun checkNullString(string: String): Boolean {
        return TextUtils.isEmpty(string)
    }

//    fun loadWebView(webViewLayout: RelativeLayout): AppWebView? {
//        var webView: AppWebView? = null
//        if (webViewLayout.childCount == 0) {
//            webView = BellApp.getInstance().getAppWebView()
//            if (webView!!.getParent() != null) {
//                (webView!!.getParent() as ViewGroup).removeView(webView)
//            }
//            webViewLayout.addView(webView)
//
//        }
//        return webView
//    }
//
//    fun startLoadingWebAppInBackground(mContext: Context) {
//        /*Start loading web app in background as soon as we got JSESSION ID*/
//        val appWebView = AppWebView(mContext, NetworkConfiguration.webAppURL)
//        BellApp.getInstance().setAppWebView(appWebView)
//    }

//    /**
//     * @param simpleText
//     * @return encrypted string ,
//     */
//    fun encrypt(simpleText: String): String? {
//
//        try {
//            val secretKey = generateSecurityKey() ?: return null
//            val cipher = Cipher.getInstance("AES")
//            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
//            val encryptedByteValue = cipher.doFinal(simpleText.toByteArray(charset("utf-8")))
//            return Base64.encodeToString(encryptedByteValue, Base64.NO_PADDING)
//        } catch (e: NoSuchAlgorithmException) {
//            e.printStackTrace()
//        } catch (e: NoSuchPaddingException) {
//            e.printStackTrace()
//        } catch (e: InvalidKeyException) {
//            e.printStackTrace()
//        } catch (e: BadPaddingException) {
//            e.printStackTrace()
//        } catch (e: UnsupportedEncodingException) {
//            e.printStackTrace()
//        } catch (e: IllegalBlockSizeException) {
//            e.printStackTrace()
//        }
//
//        return null
//    }

//    fun decrypt(encryptedText: String): String? {
//        try {
//            val secretKey = generateSecurityKey() ?: return null
//
//            var cipher: Cipher? = null
//
//            cipher = Cipher.getInstance("AES")
//            cipher!!.init(Cipher.DECRYPT_MODE, secretKey)
//            val decryptedValue64 = Base64.decode(encryptedText, Base64.NO_PADDING)
//            val decryptedByteValue = cipher.doFinal(decryptedValue64)
//            return String(decryptedByteValue, /*"utf-8"*/ Charsets.UTF_8)
//
//        } catch (e: NoSuchAlgorithmException) {
//            e.printStackTrace()
//        } catch (e: NoSuchPaddingException) {
//            e.printStackTrace()
//        } catch (e: InvalidKeyException) {
//            e.printStackTrace()
//        } catch (e: BadPaddingException) {
//            e.printStackTrace()
//        } catch (e: UnsupportedEncodingException) {
//            e.printStackTrace()
//        } catch (e: IllegalBlockSizeException) {
//            e.printStackTrace()
//        }
//
//        return null
//    }

//    /**
//     * Algorithm to create the key for encryption and decryption
//     * retuns null if exceptions occurs during key creation
//     */
//    private fun generateSecurityKey(): SecretKey? {
//        val appSecurityKey = ca.bell.selfserve.utility.BuildConfig.SecurityAppKey
////        "jkvjsnlj99879%&*&^*%90809aqiendl./-i-08-+_)/*-+"
//
//        var installationTime = BellApp.getInstance().getSharedPreference().getStringValue(AppConstant.SharedPrefrencesConstants.APPLICATION_INSTALLATION_TIME)
//        if (TextUtils.isEmpty(installationTime)) {
//            installationTime = SystemClock.currentThreadTimeMillis().toString()
//            BellApp.getInstance().getSharedPreference().setValue(AppConstant.SharedPrefrencesConstants.APPLICATION_INSTALLATION_TIME, installationTime)
//        }
//        try {
//            var key = (appSecurityKey + installationTime).toByteArray(charset("UTF-8"))
//            val sha = MessageDigest.getInstance("SHA-1")
//            key = sha.digest(key)
//            key = Arrays.copyOf(key, 32) // use only first 256 bit
//            return SecretKeySpec(key, "AES")
//        } catch (e: NoSuchAlgorithmException) {
//            e.printStackTrace()
//        } catch (e: UnsupportedEncodingException) {
//            e.printStackTrace()
//        }
//
//        return null
//    }

    fun showErrorSingleButton(mContext: Context, title: String, message: String, btnText: String, iErrorDialogListner: IErrorDialogListner) {
        val appDialog = AppDialog.AppDialogBuilder(title, message)
                .setcancelBtnText(btnText)
                .sethideOkButton(true)
                .sethasSmallBtn(true)
                .build()
        BellErrorDialog(mContext, appDialog, iErrorDialogListner).showDialog()

    }

    fun startLoadingWebAppInBackground(bellApp: BellApp) {

    }
}

