package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class ContractDistributionInfo(

        @field:SerializedName("contrDistributionMedia")
        val contrDistributionMedia: ContrDistributionMedia? = null,

        @field:SerializedName("language")
        val language: Language? = null,

        @field:SerializedName("contrPreference")
        val contrPreference: String? = null
)