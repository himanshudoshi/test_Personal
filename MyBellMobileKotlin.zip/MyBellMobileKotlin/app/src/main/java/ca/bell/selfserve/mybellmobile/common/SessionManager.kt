package ca.bell.selfserve.mybellmobile.common

/**
 * Created by GG00539076 on 3/26/2018.
 * <br></br>
 * This class is used to maintain the session.
 * For the Segregation inner class is created.
 */
class SessionManager {
    private var timestamp_prev: Long = 0
    private val ALLOWED_IDLE_TIME = (1 * 60 * 1000).toLong()

    val isSessionDestroyed: Boolean
        get() {
            if (timestamp_prev == 0L) {
                return false
            }
            val current = System.currentTimeMillis()
            val difference = current - timestamp_prev
            return difference >= ALLOWED_IDLE_TIME
        }

    fun startIdleState() {
        timestamp_prev = System.currentTimeMillis()
    }

    fun resetSession() {
        timestamp_prev = 0
    }
}