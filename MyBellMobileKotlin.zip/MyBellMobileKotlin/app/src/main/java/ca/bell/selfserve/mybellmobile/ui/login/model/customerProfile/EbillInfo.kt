package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class EbillInfo(

        @field:SerializedName("ebillStartDate")
        val ebillStartDate: Long? = null,

        @field:SerializedName("ebillEndDate")
        val ebillEndDate: Long? = null,

        @field:SerializedName("isEBillEnrolled")
        val isEBillEnrolled: Boolean? = null,

        @field:SerializedName("isEBillNotifyEnabled")
        val isEBillNotifyEnabled: Boolean? = null
)