package ravipatel.com.encrydecrypoc

import android.content.Context
import android.os.Build
import ca.bell.selfserve.mybellmobile.sharedpreferences.SharedPreferenceManager
import java.security.Key
import java.security.KeyPair

class EncryptionManager {


    lateinit var masterKey:KeyPair
    lateinit var keyBuilder: KeyBuilder
    lateinit var key:Key

    var currentEncryptionAlgo:String? = null

    val algoType = "algoType"


    val AES = "AES"
    val RSA = "RSA"

    private constructor( context: Context){

        initData(context)

    }


    companion object {

        private val ALIAS = "MASTER_KEY"

        @Volatile
        private var INSTANCE: EncryptionManager? = null
        fun getInstance(context: Context) =
                INSTANCE ?: synchronized(this) {
                    INSTANCE
                            ?: EncryptionManager(context)
                }
    }

    fun initData(context: Context) {

        keyBuilder = KeyBuilder(context)

        currentEncryptionAlgo = SharedPreferenceManager.getInstance(context).getStringValue(algoType)

        if(currentEncryptionAlgo == null)
        {
            currentEncryptionAlgo = getEncryptionAlgo(context)
            saveCurrentEncryptionAlgo(currentEncryptionAlgo!!,context)
        }

        initEncryptionParameters()
    }

    fun initEncryptionParameters(){

        if (currentEncryptionAlgo == AES)
        {
            key = keyBuilder.getAESKey(ALIAS)
        }
        else
        {
            keyBuilder.createAndroidKeyStoreAsymmetricKey(ALIAS)
            masterKey = keyBuilder.getAndroidKeyStoreAsymmetricKeyPair(ALIAS)!!

        }

    }

    private fun saveCurrentEncryptionAlgo(encryptionAlgo:String,context: Context){
        SharedPreferenceManager.getInstance(context).setValue(algoType,encryptionAlgo)
    }

    private fun getEncryptionAlgo(context:Context):String{

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            return AES
        }
        else
        {
            return RSA
        }
    }

    fun encryptData(plainText:String):String{

        if (currentEncryptionAlgo == AES)
            return AESManager.encrypt(plainText,key)
        else
            return RSAManager.encrypt(plainText, masterKey?.public)

    }

    fun decryptData(encryptedText:String):String{

        if (currentEncryptionAlgo == AES)
            return AESManager.decrypt(encryptedText,key)
        else
            return RSAManager.decrypt(encryptedText, masterKey?.private)
    }
}