package ravipatel.com.encrydecrypoc

import android.util.Base64
import java.security.Key
import javax.crypto.Cipher

object RSAManager {

    val TRANSFORMATION_RSA = "RSA/ECB/PKCS1Padding"

    val cipher: Cipher = Cipher.getInstance(TRANSFORMATION_RSA)

    fun encrypt(data: String, key: Key?): String {
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val bytes = cipher.doFinal(data.toByteArray())
        return Base64.encodeToString(bytes, Base64.DEFAULT)
    }

    fun decrypt(data: String, key: Key?): String {
        cipher.init(Cipher.DECRYPT_MODE, key)
        val encryptedData = Base64.decode(data, Base64.DEFAULT)
        val decodedData = cipher.doFinal(encryptedData)
        return String(decodedData)
    }
}