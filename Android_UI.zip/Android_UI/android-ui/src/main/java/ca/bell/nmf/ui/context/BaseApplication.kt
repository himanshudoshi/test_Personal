package ca.bell.nmf.ui.context

import android.app.Application
import ca.bell.nmf.ui.R
import ca.bell.nmf.ui.FontsManager
import ca.bell.nmf.ui.localization.InternalData
import ca.bell.nmf.ui.localization.LanguageManager

abstract class BaseApplication : Application() {

    enum class TYPE {
        PC_MOBILE, LUCKY_MOBILE, VIRGIN_MOBILE, BELL_MOBILE, NONE
    }

    private var appType: TYPE = TYPE.NONE

    override fun onCreate() {
        super.onCreate()

        //This initializes project or app type. To change please go to nmf.xml file and change
        appType = getAppType()
        manageLanguageLocaleKeys()
        //Initialize fonts manager. Please use
        FontsManager.getInstance(this, appType)
    }

    /**
     * this method will:
     * 1. check if device locale is EN or FR. If none of them, will store the Device Language Locale in
     * shared preferences.
     * 2. If the Device Language Locale is EN, but the app SharedPref flag is set to FR, this method will
     * override the value in SharedPref with EN. The same will be applied for FR (EN) logic.
     */
    private fun manageLanguageLocaleKeys() {
        val languageManager = LanguageManager(this)
        val internalData = InternalData(this)
        val deviceLanguageLocale = languageManager.getContextLanguageLocale()
        val prefixUserLanguageLocale = languageManager.userLocaleLanguage.substring(0..1)
        internalData.storeUserPreference(InternalData.DEVICE_LANGUAGE_KEY,
                languageManager.getContextLanguageLocale())
        if (!deviceLanguageLocale.startsWith(prefixUserLanguageLocale) &&
                (deviceLanguageLocale.startsWith(LanguageManager.ENGLISH_LANGUAGE_ACRONYM) ||
                        deviceLanguageLocale.startsWith(LanguageManager.FRENCH_LANGUAGE_ACRONYM))) {
            internalData
                    .storeUserPreference(InternalData.CURRENT_LANGUAGE_KEY, deviceLanguageLocale.substring(0..1))
        }
    }

    private fun getAppType(): TYPE {
        val appType = resources.getString(R.string.app_type)
        return when (appType) {
            resources.getString(R.string.pc_mobile_app) -> TYPE.PC_MOBILE
            resources.getString(R.string.lucky_mobile_app) -> TYPE.LUCKY_MOBILE
            resources.getString(R.string.virgin_mobile_app) -> TYPE.VIRGIN_MOBILE
            resources.getString(R.string.bell_mobile_app) -> TYPE.BELL_MOBILE
            else -> {
                throw RuntimeException("Undefined app type, \"none\" can't be an app type. " +
                        "Please check your app_type property under nmf.xml file.")
            }
        }
    }
}