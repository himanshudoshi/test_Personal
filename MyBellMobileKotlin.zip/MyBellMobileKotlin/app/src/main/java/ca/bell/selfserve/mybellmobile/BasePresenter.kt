package ca.bell.selfserve.mybellmobile.base

import android.support.v4.app.LoaderManager

/**
 * Created by Gaurav Gupta on 5/1/2018.
 * This is a base class of presenter contract between view class and it's presenter
 */
interface BasePresenter {

    fun attachView(view: Any)

    fun detachView()

    fun attachLoader(loaderManager: LoaderManager)
}