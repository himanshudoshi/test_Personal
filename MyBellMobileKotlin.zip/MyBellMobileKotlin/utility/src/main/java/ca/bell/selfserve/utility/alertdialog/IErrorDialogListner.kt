package ca.bell.selfserve.mybellmobile.alertdialog

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import android.app.Dialog

interface IErrorDialogListner {

    fun onOkButtonPressed(dialog: Dialog)
    fun onCancelButtonPressed(dialog:Dialog)
}