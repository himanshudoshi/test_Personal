package ca.bell.nmf.ui.context

import android.app.AlertDialog
import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import android.util.DisplayMetrics
import android.view.WindowManager
import ca.bell.nmf.ui.R
import ca.bell.nmf.ui.localization.ILocalization
import ca.bell.nmf.ui.localization.InternalData
import ca.bell.nmf.ui.localization.LanguageManager
import java.util.*

open class BaseActivity : AppCompatActivity(), ILocalization {

    private var localeLanguage: String? = null
    private var languageAlertDialog: AlertDialog? = null

    override fun attachBaseContext(newBase: Context?) {
        val languageManager = LanguageManager(newBase!!)
        super.attachBaseContext(languageManager.updateThenSetPrefLanguage(languageManager.userLocaleLanguage))
    }

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        handleOrientation()
        super.onCreate(savedInstanceState, persistentState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        handleOrientation()
        if (localeLanguage == null) {
            localeLanguage = LanguageManager(this).userLocaleLanguage
        }
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        if (LanguageManager(this).shouldPromptLanguageChange()) {
            requestLanguageChange()
        }
    }

    override fun onStop() {
        super.onStop()
        languageAlertDialog?.dismiss()
    }

    override fun onLanguageChanged(languageName: String) {
        LanguageManager(this).updateThenSetPrefLanguage(this, languageName)
        changeLanguageResources()
    }

    override fun requestLanguageChange() {
        val dialogBuilder = AlertDialog.Builder(this, R.style.NMF_Styles_AlertDialog_Default)
        dialogBuilder
                .setMessage(getString(ca.bell.nmf.ui.R.string.please_select_language_of_application))
                .setPositiveButton(getString(ca.bell.nmf.ui.R.string.english)) { _, _ ->
                    InternalData(this)
                            .storeUserPreference(InternalData.SHOULD_SHOW_LANGUAGE_SELECT_DIALOG, false)
                    onLanguageChanged(LanguageManager.ENGLISH_LANGUAGE_ACRONYM)
                }
                .setNegativeButton(ca.bell.nmf.ui.R.string.french) { _, _ ->
                    InternalData(this)
                            .storeUserPreference(InternalData.SHOULD_SHOW_LANGUAGE_SELECT_DIALOG, false)
                    onLanguageChanged(LanguageManager.FRENCH_LANGUAGE_ACRONYM)
                }
        languageAlertDialog = dialogBuilder.create()
        languageAlertDialog?.setCancelable(false)
        languageAlertDialog?.show()

        val layoutParams = WindowManager.LayoutParams()
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val deviceScreenWidth = displayMetrics.widthPixels
        layoutParams.copyFrom(languageAlertDialog?.window?.attributes)
        layoutParams.width = (deviceScreenWidth * 0.8).toInt()
        languageAlertDialog?.window?.attributes = layoutParams
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            languageAlertDialog?.window?.setElevation(60f)
        }
    }

    fun handleOrientation() {
        if (!resources.getBoolean(R.bool.tablet)) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            return
        }
    }

    fun changeLanguageResources() {
        val currentResources = this.resources
        val displayMetrics = currentResources.displayMetrics
        val configuration = currentResources.configuration
        configuration.setLocale(Locale(LanguageManager(this).userLocaleLanguage))
        currentResources.updateConfiguration(configuration, displayMetrics)
    }
}