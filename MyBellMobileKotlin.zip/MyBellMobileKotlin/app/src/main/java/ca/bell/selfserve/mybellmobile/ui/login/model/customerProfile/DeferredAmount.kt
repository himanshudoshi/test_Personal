package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class DeferredAmount(

        @field:SerializedName("nil")
        val nil: Boolean? = null,

        @field:SerializedName("typeSubstituted")
        val typeSubstituted: Boolean? = null,

        @field:SerializedName("globalScope")
        val globalScope: Boolean? = null,

        @field:SerializedName("scope")
        val scope: String? = null,

        @field:SerializedName("name")
        val name: String? = null,

        @field:SerializedName("declaredType")
        val declaredType: String? = null,

        @field:SerializedName("value")
        val value: Double? = null
)