package ca.bell.selfserve.data.network.baseNetworkApi

import android.os.AsyncTask
import android.os.CountDownTimer
import android.util.Log

import ca.bell.selfserve.data.network.model.NetworkModel

/**
 * Created by GG00539076 on 2/23/2018.
 */

abstract class BaseNetworkApi(protected var networkModel: NetworkModel) {
    private var reconnectionAllowed = true
    private var count: Int = 0
    private val MAX_RECONNECTION_ATTEMPT = 3// field for maximum allowed reconnection attempts.

    val isRetryAllowedOnFailure: Boolean
        get() = count < MAX_RECONNECTION_ATTEMPT && reconnectionAllowed && networkModel.IsRetryIfFail()

    fun callApi() {
        onNetworkApiCalled()
        NetworkAsyncTask().execute()
    }


    protected fun onConnectionLost() {

        Log.e(BaseNetworkApi::class.java.canonicalName, "Retrying after " + WAITING_TIME_DURING_RECONNECTION / 1000f + " sec " + System.currentTimeMillis() + " "
                + networkModel.getNetworkURL())

        object : CountDownTimer(WAITING_TIME_DURING_RECONNECTION, 100) {
            override fun onTick(millisUntilFinished: Long) {}

            override fun onFinish() {
                val isNwCallAllowed = isRetryAllowedOnFailure
                if (isNwCallAllowed) {
                    callApi()
                } else {
                    Log.e(BaseNetworkApi::class.java.canonicalName, "No retry left or retry not allowed")
                }
            }
        }.start()
    }


    fun setReconnectionAllowed(isReconnectionAllowed: Boolean) {
        this.reconnectionAllowed = isReconnectionAllowed
    }

    fun onNetworkApiCalled() {
        count = count + 1
    }


    protected abstract fun onPreExecute()

    protected abstract fun doInBackground()

    protected abstract fun onPostExecute()

    inner class NetworkAsyncTask : AsyncTask<Void?, Void?, Void?>() {

        override fun onPreExecute() {
            super.onPreExecute()
            this@BaseNetworkApi.onPreExecute()
        }

        override fun doInBackground(vararg voids: Void?): Void? {
            this@BaseNetworkApi.doInBackground()
            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            this@BaseNetworkApi.onPostExecute()
        }
    }

    companion object {

        private val WAITING_TIME_DURING_RECONNECTION = 3500L
    }

}

