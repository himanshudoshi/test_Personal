package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class Subscribers(

        @field:SerializedName("subscriber")
        val subscriber: List<SubscriberItem?>? = null
)