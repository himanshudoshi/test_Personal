package ca.bell.selfserve.data.network.api

import ca.bell.selfserve.data.network.model.*
import ca.bell.selfserve.data.network.service.ApiRestCall

/**
 * Created by GG00539076 on 5/23/2018.
 */
class SplashApi {

    fun callConfigApi(networkBaseCallback: NetworkBaseCallback) {

        val prefix = NetworkConfiguration.getInstance().configurationURL
        val finalURL = NetworkConfiguration.getInstance().configurationURL + "MBM_Config.json"

//        // Creating call as we are going to define retrofit interface
//        val apiService = ApiClient.getInstance(prefix).getClient(APIService::class.java)
//        val call = apiService.getConfiguration()
//        val extraData = HashMap<String, Any>()
//        //        extraData.put(RetrofitNetworkManager.CONSTANT_CALL, call);
//        extraData[RetrofitNetworkManager.RETRO_PREFIX_URL] = prefix

        val networkModel = NetworkModel.NetworkModelBuilder()
                .setBaseCallback(networkBaseCallback)
                .setNetworkUrl(finalURL)
                .setMethod(CallType.GET)
                .setNetworkType(NetworkConfiguration.NetworkTypes.PEGA_NETWORK)
                .setNetworkInterface(NetworkConfiguration.getInstance().defaultNetworkInterface)
                .setKey(ApiConstant.GET_CONFIG_KEY)
//                .setExtraObject(extraData)
                .build()

        ApiRestCall(networkModel).addRequest()

    }


}