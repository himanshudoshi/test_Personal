package ca.bell.selfserve.mybellmobile.base

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.View
import ca.bell.selfserve.mybellmobile.BellApp

/**
 * Created by Gaurav Gupta
 * base acivity of all class
 */
open class BaseActivity : AppCompatActivity() {
    private var baseToolbar: Toolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    fun initToolbar(toolbarId: Int) {
        baseToolbar = findViewById(toolbarId)
        setSupportActionBar(baseToolbar)

    }

    fun showToolbar() {
        baseToolbar!!.visibility = View.VISIBLE
    }

    fun hideToolbar() {
        baseToolbar!!.visibility = View.GONE
    }


    fun setToolbarTitle(title: String) {
        supportActionBar!!.setDisplayShowTitleEnabled(true)
        supportActionBar!!.title = title
    }


    fun hideBackButton() {
        supportActionBar!!.setDisplayHomeAsUpEnabled(false)
        supportActionBar!!.setDisplayShowHomeEnabled(false)
    }

    fun showBackButton() {
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        supportActionBar!!.setHomeButtonEnabled(true)
    }


    override fun onResume() {
        super.onResume()
    }



    override fun onPause() {
        super.onPause()

    }


    protected interface SessionManagerCallback {
        fun onSessionDestroyed()
    }

}
