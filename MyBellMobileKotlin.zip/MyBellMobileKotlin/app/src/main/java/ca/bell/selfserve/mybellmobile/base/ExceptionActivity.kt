package ca.bell.selfserve.mybellmobile

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class ExceptionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exception)
        // Implementation
    }

}