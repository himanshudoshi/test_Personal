package ca.bell.selfserve.data.network.service

import android.util.Log
import ca.bell.selfserve.data.DataSingleton
import ca.bell.selfserve.data.network.model.NetworkModel

import com.android.volley.Response

/**
 * Created by gg00539076 on 4/5/2018.
 */

class ApiRestCall {

    init {
        initialiseVolleyHelper()
    }

    val networkModel: NetworkModel;

    constructor(networkModel: NetworkModel) {
        this.networkModel = networkModel
    }

    private fun initialiseVolleyHelper() {
        volleyHelper = DataSingleton.getDataSingleton().getVolleyHelperImpl()
    }


    fun clearCache() {
        volleyHelper.clearCache(networkModel.getKey())
    }


    fun cancelRequest() {
        volleyHelper.cancelRequest(networkModel.getKey())
    }

    fun getEndPoint() {
//        ToDo: endpoint work left
    }

    fun getHeader() {

    }


    fun addRequest() {
        volleyHelper.execute(networkModel,
                getStringListener(networkModel),
                getErrorListener(networkModel),
                getRetryErrorListener())
    }


    private fun getRetryErrorListener(): RetryErrorListener {
        return object : RetryErrorListener {
            override fun onErrorWhileRetry(e: Exception) {
                Log.e(javaClass.getCanonicalName(), e.message)
            }
        }
    }


    private fun getStringListener(modelVolley: NetworkModel): VolleyStringListener {
        return object : VolleyStringListener {
            lateinit var headers: Map<String, ArrayList<String>>;

            override fun onHeadersReceived(headers: Map<String, ArrayList<String>>) {
                this.headers = headers;
            }

            override fun onResponse(response: String) {
                modelVolley.getIbaseCallbackNetwork().onSuccessfulResponse(response, headers)
            }
        };
    }


    private fun getErrorListener(networkModel: NetworkModel): Response.ErrorListener {
        val errorListener = Response.ErrorListener { error ->
            networkModel.getIbaseCallbackNetwork().onFailure(error)
        }
        return errorListener
    }


    companion object {
        lateinit var volleyHelper: VolleyHelperImpl
    }


}


