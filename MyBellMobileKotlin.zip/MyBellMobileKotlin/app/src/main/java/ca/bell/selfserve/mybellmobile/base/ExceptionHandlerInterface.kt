package ca.bell.selfserve.mybellmobile.base

interface ExceptionHandlerInterface {
    fun onGettingException(value:Int)
}
