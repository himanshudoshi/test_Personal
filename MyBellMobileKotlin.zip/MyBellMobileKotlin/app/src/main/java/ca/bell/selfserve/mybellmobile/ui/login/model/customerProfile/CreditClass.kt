package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

import com.google.gson.annotations.SerializedName

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
data class CreditClass(

        @field:SerializedName("code")
        val code: String? = null,

        @field:SerializedName("value")
        val value: String? = null
)