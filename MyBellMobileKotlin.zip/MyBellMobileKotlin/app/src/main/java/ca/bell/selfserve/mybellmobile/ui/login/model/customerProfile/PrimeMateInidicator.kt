package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class PrimeMateInidicator(

        @field:SerializedName("code")
        val code: String? = null,

        @field:SerializedName("value")
        val value: String? = null
)