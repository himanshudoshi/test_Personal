package ca.bell.selfserve.mybellmobile.ui.splash

import android.content.Context
import ca.bell.selfserve.mybellmobile.base.BasePresenter
import ca.bell.selfserve.mybellmobile.base.BaseView
import ca.bell.selfserve.mybellmobile.ui.splash.model.ConfigurationResponse
import ca.bell.selfserve.mybellmobile.ui.splash.model.ForceUpgradeCMSContent
import java.util.HashMap

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
class SplashContract {

    /**
     * interface that splash activity will implement
     */
    interface ISplashView : BaseView<ISplashPresenter> {

        /**
         * method to show login screen
         */
        fun showLoginScreen()

        /**
         * method to show landing screen
         */
        fun showLandingScreen()


        fun getConfigurationFromServer()

        fun checkNetworkConnection()

        fun showForceUpgradePopup(forceUpgradeCMSContent: List<ForceUpgradeCMSContent>)


        /**
         * Method to show pop up to device lanuguage
         */
        fun displayLanguageSelectionPopup(): Boolean

        /**
         * method to show network connection error
         *
         * @return true
         */
        fun showConnectionError(): Boolean


    }

    /**
     * interface that splash presenter will implement
     */
    interface ISplashPresenter : BasePresenter {


        /**
         * method to get application language
         * check application language from shared preferences is available if ture then return application language
         * else get from locale and return
         *
         * @return application language
         */
        val applicationLanguage: String

        val requiredPermissionNames: HashMap<String, String>


        /**
         * Method to set defalut language of the application
         *
         * @param language
         * @return
         */
        fun setAppLanguage(language: String): Boolean

        /**
         * Method to call configuration Api call
         */
        fun callConfigurationApi()


        /**
         * method to check if app language is English Or French
         *
         * @return true if language is English or French else return false
         */
        fun checkAppLanguageEnglishOrFrench(): Boolean

        fun checkIfNetworkIsAvailable()

        /**
         * Method to check availability of location permissions
         *
         * @return true if location permission available otherwise false
         */
        fun checkLocationPermissionAvailability(mContext: Context): Boolean

        fun proceedWithAppLanguage()

        fun tryAutoLogin()

        /**
         * method to check whether we need to show force upgrade or not
         *
         * @param configurationResponse
         * @return
         */
        fun isForceUpgrade(configurationResponse: ConfigurationResponse): Boolean

        fun goToPlayStore()
    }
}
