package ca.bell.nmf.ui.view

import android.content.Context
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import ca.bell.nmf.ui.R
import kotlinx.android.synthetic.main.view_ban_details_layout.view.*


/**
 * This class represents a custom view from BEll Mobile Project. Most of landing pages on our four
 * streams have Ban details View, and this class represents well that shared view.
 * @constructor creates BanDetailsView from all params either coming from xml or code.
 * @param mContext View's context.
 * @param attrs View's attribute set.
 * @author Sami LASSED
 */
class BanDetailsView(private val mContext: Context, private val attrs: AttributeSet?) : ConstraintLayout(mContext, attrs) {

    /**
     * @property primaryButton reference to primary button. Primary buttons are the ones with full
     * fill background. This reference is created for any future customizations.
     */
    val primaryButton = banPrimaryButton

    /**
     * @property secondaryButton reference to secondary button. Secondary buttons are the ones with white
     * fill background and outline borders. This reference is created for any future customizations.
     */
    val secondaryButton = banSecondaryButton

    /**
     * @property amountTextView reference to details text view.
     */
    val amountTextView = banBillAmountTextView

    /**
     * @constructor creates BanDetailsView from all params either coming from xml or code.
     * */
    //constructor(mContext: Context): this(mContext, null)

    init {
        initView()
    }

    /**
     * initialise view with attribute set
     * */
    private fun initView() {

        LayoutInflater.from(mContext).inflate(R.layout.view_ban_details_layout, this, true)

        attrs?.let {
            val attributes = mContext.obtainStyledAttributes(attrs, R.styleable.ban_details)

            val billReference = attributes.getString(R.styleable.ban_details_billRef)
            val billAmount = attributes.getString(R.styleable.ban_details_billAmount)
            val dueDate = attributes.getString(R.styleable.ban_details_dueDate)

        }
    }

    /**
     * @param billRef A string that contains bill's reference.
     * @return a reference of the object itself. This is made for code readability.
     * Updating view's bill reference text.
     * */
    fun setBillReference(billRef: String): BanDetailsView {
        billRef?.let {
            banBillRefTextView.text = billRef
        }
        return this
    }

    /**
     * @param billRef An integer that contains bill's reference.
     * @return a reference of the object itself. This is made for code readability.
     * Updating view's bill reference text.
     * */
    fun setBillReference(billRef: Int): BanDetailsView {
        if (billRef > 0) {
            banBillRefTextView.text = "$billRef"
        }

        return this
    }

    /**
     * @param amount A string that contains bill's amount.
     * @return a reference of the object itself. This is made for code readability.
     * Updating view's bill amount text.
     * */
    fun setBillAmount(amount: String): BanDetailsView {
        amount?.let {
            banBillAmountTextView.text = "$ $amount"
        }
        return this
    }

    /**
     * @param amount An integer that contains bill's amount.
     * @return a reference of the object itself. This is made for code readability.
     * Updating view's bill amount text.
     * */
    fun setBillAmount(amount: Float): BanDetailsView {
        if (amount > 0f) {
            banBillAmountTextView.text = "$ $amount"
        }
        return this
    }

    /**
     * @param date A string that contains bill's due date.
     * @return a reference of the object itself. This is made for code readability.
     * Updating view's bill due date text.
     * */
    fun setDueDate(date: String): BanDetailsView {
        date?.let {
            banBillDueDateTextView.text = resources.getString(R.string.due_by, it)
        }
        return this
    }

    /**
     * @param customDateText A string that contains date along with custom prefix text
     * @return a reference of the object itself. This is made for code readability.
     * Updating view's bill due date text.
     * */
    fun setDateText(customDateText: String): BanDetailsView {
        customDateText?.let {
            banBillDueDateTextView.text = customDateText
        }
        return this
    }

    /**
     * @param listener click listener for primary button.
     * @return a reference of the object itself. This is made for code readability.
     * */
    fun addPrimaryButtonClickListener(listener: OnClickListener): BanDetailsView {
        banPrimaryButton.setOnClickListener(listener)
        return this
    }

    /**
     * @param listener click listener for secondary button.
     * @return a reference of the object itself. This is made for code readability.
     * */
    fun addSecondaryButtonClickListener(listener: OnClickListener): BanDetailsView {
        banSecondaryButton.setOnClickListener(listener)
        return this
    }


    /**
     * This method will show or hide warning icon.
     * @param showWarning boolean value
     *@return a reference of the object itself. This is made for code readability.
     */
    fun showWarningIcon(showWarning: Boolean): BanDetailsView {
        if (showWarning) {
            banBillErrorWarning.visibility = View.VISIBLE
        } else {
            banBillErrorWarning.visibility = View.GONE
        }

        return this
    }

    /**
     * This method will replace default warning icon with custom icon provided.
     * @param resId drawable resource id
     *@return a reference of the object itself. This is made for code readability.
     */
    fun changeWarningIcon(resId: Int): BanDetailsView {
        val checkExistence:Int = mContext.resources.getIdentifier(resId.toString() , "drawable", mContext.packageName)
       if (checkExistence !=0){
           banBillErrorWarning.setImageResource(resId)
       }
        return this
    }

    /**
     * @param accountType A string that contains account type.
     * @return a reference of the object itself. This is made for code readability.
     * Updating account type text.
     * */
    fun setAccountType(accountType: String): BanDetailsView {
        accountType?.let {
            banBillTitleTextView.text = accountType
        }
        return this
    }

    /**
     * @param customAmountString A string that contains bill's amount along with prefix or postfix currency symbol.
     * @return a reference of the object itself. This is made for code readability.
     * Updating view's bill amount text.
     * */
    fun setCustomBillAmount(customAmountString: String): BanDetailsView {
        customAmountString?.let {
            banBillAmountTextView.text = customAmountString
        }
        return this
    }

    /**
     * This method will show or collapse ban detail button views.
     * @param isCollapse boolean value
     *@return a reference of the object itself. This is made for code readability.
     */
    fun collapse(isCollapse: Boolean): BanDetailsView {
        if (isCollapse) {
            banPrimaryButton.visibility = View.GONE
            banSecondaryButton.visibility = View.GONE
        } else {
            banPrimaryButton.visibility = View.VISIBLE
            banSecondaryButton.visibility = View.VISIBLE
        }
        return this
    }

    /**
     * This method will hide amount and due date textview and display bill not available view
     * @param isBillNotAvailable boolean value
     * @return a reference of the object itself. This is made for code readability.
     * Updating view's bill due date text.
     * */
    fun setBillNotAvailable(isBillNotAvailable: Boolean = false): BanDetailsView {
        if (isBillNotAvailable) {
            banBillAmountTextView.visibility = View.GONE
            banBillDueDateTextView.visibility = View.GONE
            banBillNotAvailableTextView.visibility = View.VISIBLE
            banBillNotAvailableTextView.text = context.getString(R.string.bill_not_available)
        }
        return this
    }
}