package ca.bell.nmf.ui.shimmer

import android.content.Context
import android.util.AttributeSet
import com.facebook.shimmer.ShimmerFrameLayout

/**
 * Class to create shimmer progress effect
 * Implement in XML files
 * @param context
 * @param attrs
 * @param defStyleAttr
 */
class BellShimmerLayout @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : ShimmerFrameLayout(context, attrs, defStyleAttr) {
    /**
     * Method to start shimmer effect animation
     */
    override fun startShimmerAnimation() {
        super.startShimmerAnimation()
    }
    /**
     * Method to stop shimmer effect animation
     */
    override fun stopShimmerAnimation() {
        super.stopShimmerAnimation()
    }
}