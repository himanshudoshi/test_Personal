package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class PaymentInfo(

        @field:SerializedName("bankInfo")
        val bankInfo: Any? = null,

        @field:SerializedName("creditCardInfo")
        val creditCardInfo: Any? = null,

        @field:SerializedName("paymentMethod")
        val paymentMethod: PaymentMethod? = null
)