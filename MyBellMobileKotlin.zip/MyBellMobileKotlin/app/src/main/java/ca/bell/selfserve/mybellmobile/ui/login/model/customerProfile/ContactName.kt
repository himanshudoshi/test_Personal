package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class ContactName(

        @field:SerializedName("generation")
        val generation: Any? = null,

        @field:SerializedName("firstName")
        val firstName: String? = null,

        @field:SerializedName("lastName")
        val lastName: String? = null,

        @field:SerializedName("additionalTitle")
        val additionalTitle: Any? = null,

        @field:SerializedName("nameSuffix")
        val nameSuffix: Any? = null,

        @field:SerializedName("middleName")
        val middleName: Any? = null,

        @field:SerializedName("salutation")
        val salutation: Any? = null,

        @field:SerializedName("title")
        val title: String? = null
)