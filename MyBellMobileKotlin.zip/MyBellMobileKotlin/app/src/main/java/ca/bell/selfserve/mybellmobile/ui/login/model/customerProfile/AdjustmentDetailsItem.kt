package ca.bell.selfserve.mybellmobile.ui.login.model.customerProfile

/**
 * Created by Gaurav Gupta on 5/3/2018.
 */
import com.google.gson.annotations.SerializedName

data class AdjustmentDetailsItem(

        @field:SerializedName("date")
        val date: Long? = null,

        @field:SerializedName("amount")
        val amount: Double? = null
)